import time
import hmac
import hashlib
import uuid
import aiohttp
import json
import logging
from config import BINANCE_API_KEY, BINANCE_SECRET_KEY

logger = logging.getLogger(__name__)

BASE_URL = "https://bpay.binanceapi.com"

def generate_nonce(length=32):
    return uuid.uuid4().hex[:length]

def generate_signature(timestamp, nonce, body_str, secret_key):
    payload = f"{timestamp}\n{nonce}\n{body_str}\n"
    signature = hmac.new(
        secret_key.encode('utf-8'),
        payload.encode('utf-8'),
        hashlib.sha512
    ).hexdigest().upper()
    return signature

async def create_binance_order(amount, description="Deposit Balance", order_id=None):
    """
    Creates a Binance Pay order and returns the payment URL.
    """
    if not order_id:
        order_id = f"PAY_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        
    endpoint = "/binancepay/openapi/v2/order"
    url = f"{BASE_URL}{endpoint}"
    
    # Binance Pay Order Payload
    payload = {
        "env": {
            "terminalType": "WEB"
        },
        "merchantTradeNo": order_id,
        "orderAmount": float(amount),
        "currency": "USDT",
        "goods": {
            "goodsType": "02",  # 01: Physical, 02: Virtual/Digital
            "goodsCategory": "Z000",  # Others
            "referenceGoodsId": "deposit",
            "goodsName": description
        }
    }
    
    body_str = json.dumps(payload)
    timestamp = int(time.time() * 1000)
    nonce = generate_nonce()
    
    # Generate signature using the local secret key or fallback
    api_key = BINANCE_API_KEY
    secret_key = BINANCE_SECRET_KEY
    
    # If the user hasn't set keys, return a dummy payment flow for testing
    if not api_key or not secret_key or api_key == "YOUR_BINANCE_API_KEY" or secret_key == "YOUR_BINANCE_SECRET_KEY":
        logger.warning("Binance keys not configured. Simulating order creation.")
        # Return a mock payment URL and the generated order_id
        return {
            "success": True,
            "mock": True,
            "checkoutUrl": f"https://test.binancepay.mock/pay?order={order_id}&amount={amount}",
            "merchantTradeNo": order_id
        }
        
    headers = {
        "Content-Type": "application/json",
        "BinancePay-Timestamp": str(timestamp),
        "BinancePay-Nonce": nonce,
        "BinancePay-Certificate-SN": api_key,
        "BinancePay-Signature": signature
    }
    
    # We construct signature with actual request headers
    signature = generate_signature(timestamp, nonce, body_str, secret_key)
    headers["BinancePay-Signature"] = signature
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=payload, timeout=10) as response:
                res_data = await response.json()
                if response.status == 200 and res_data.get("status") == "SUCCESS":
                    return {
                        "success": True,
                        "mock": False,
                        "checkoutUrl": res_data["data"]["checkoutUrl"],
                        "merchantTradeNo": order_id
                    }
                else:
                    logger.error(f"Binance Order Creation Failed: {res_data}")
                    return {"success": False, "error": res_data.get("errorMessage", "Unknown error")}
    except Exception as e:
        logger.error(f"Error calling Binance API: {e}")
        return {"success": False, "error": str(e)}

async def check_binance_order_status(merchant_trade_no):
    """
    Queries Binance Pay API to check order payment status.
    Returns status: 'INITIAL', 'PENDING', 'PAID', 'CANCELED', 'EXPIRED' or 'FAILED'
    """
    endpoint = "/binancepay/openapi/v2/order/query"
    url = f"{BASE_URL}{endpoint}"
    
    payload = {
        "merchantTradeNo": merchant_trade_no
    }
    
    body_str = json.dumps(payload)
    timestamp = int(time.time() * 1000)
    nonce = generate_nonce()
    
    api_key = BINANCE_API_KEY
    secret_key = BINANCE_SECRET_KEY
    
    # Simulate payment verification if keys are dummy
    if not api_key or not secret_key or api_key == "YOUR_BINANCE_API_KEY" or secret_key == "YOUR_BINANCE_SECRET_KEY":
        logger.info("Binance keys not configured. Simulating payment check.")
        # For testing, we mock complete payment as PAID
        return {
            "success": True,
            "mock": True,
            "status": "PAID"
        }
        
    signature = generate_signature(timestamp, nonce, body_str, secret_key)
    
    headers = {
        "Content-Type": "application/json",
        "BinancePay-Timestamp": str(timestamp),
        "BinancePay-Nonce": nonce,
        "BinancePay-Certificate-SN": api_key,
        "BinancePay-Signature": signature
    }
    
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, headers=headers, json=payload, timeout=10) as response:
                res_data = await response.json()
                if response.status == 200 and res_data.get("status") == "SUCCESS":
                    # Status can be: INITIAL, PENDING, PAID, CANCELED, EXPIRED
                    status = res_data["data"]["status"]
                    return {
                        "success": True,
                        "mock": False,
                        "status": status
                    }
                else:
                    logger.error(f"Binance Status Query Failed: {res_data}")
                    return {"success": False, "error": res_data.get("errorMessage", "Unknown error")}
    except Exception as e:
        logger.error(f"Error checking Binance API status: {e}")
        return {"success": False, "error": str(e)}
