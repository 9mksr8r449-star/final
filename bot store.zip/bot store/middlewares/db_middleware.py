from aiogram import BaseMiddleware
from aiogram.types import TelegramObject
from typing import Callable, Dict, Any, Awaitable
from database import get_user, create_user
import config

class DbUserMiddleware(BaseMiddleware):
    async def __call__(
        self,
        handler: Callable[[TelegramObject, Dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: Dict[str, Any]
    ) -> Any:
        tg_event = getattr(event, "event", None)
        tg_user = None
        if tg_event and hasattr(tg_event, "from_user"):
            tg_user = tg_event.from_user
            
        if tg_user:
            user_id = tg_user.id
            username = tg_user.username or ""
            first_name = tg_user.first_name or ""
            
            # Retrieve or register user
            user = await get_user(user_id)
            if not user:
                await create_user(user_id, username, first_name)
                user = await get_user(user_id)
                
            data['db_user'] = user
            data['is_admin'] = user_id in config.ADMIN_IDS
            data['lang'] = user['language'] if user else 'en'
        else:
            data['is_admin'] = False
            data['lang'] = 'en'
            
        return await handler(event, data)
