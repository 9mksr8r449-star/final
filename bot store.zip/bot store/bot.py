import asyncio
import logging
import sys
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
import config
from database import db_init
from middlewares.db_middleware import DbUserMiddleware
from handlers import get_handlers_router
from crypto_verifier import start_auto_verification_loop

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

async def main():
    logger.info("Initializing database...")
    await db_init()
    logger.info("Database initialized successfully.")

    if not config.BOT_TOKEN or config.BOT_TOKEN == "YOUR_TELEGRAM_BOT_TOKEN":
        logger.error("BOT_TOKEN is not configured in .env! Please set it and restart.")
        sys.exit(1)

    logger.info("Setting up Bot and Dispatcher...")
    bot = Bot(token=config.BOT_TOKEN)
    
    # Using local memory storage for FSM
    dp = Dispatcher(storage=MemoryStorage())
    
    # Register outer database middleware for all update events
    dp.update.outer_middleware(DbUserMiddleware())
    
    # Register handlers router
    dp.include_router(get_handlers_router())
    
    # Start background auto-verification loop
    asyncio.create_task(start_auto_verification_loop(bot))
    
    logger.info("Starting bot polling...")
    try:
        await dp.start_polling(bot, skip_updates=True)
    except Exception as e:
        logger.critical(f"Critical error in polling: {e}")
    finally:
        await bot.session.close()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped.")
