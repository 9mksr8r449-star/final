import aiosqlite
import os
import uuid
from datetime import datetime
from config import DB_NAME

async def db_init():
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("PRAGMA foreign_keys = ON;")
        
        # Users Table
        await db.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            username TEXT,
            first_name TEXT,
            balance REAL DEFAULT 0.0,
            language TEXT DEFAULT 'en',
            referred_by INTEGER,
            referral_code TEXT UNIQUE,
            referral_balance_earned REAL DEFAULT 0.0,
            joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        
        # Products Table
        await db.execute("""
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name_ar TEXT NOT NULL,
            name_en TEXT NOT NULL,
            name_ru TEXT NOT NULL,
            description_ar TEXT NOT NULL,
            description_en TEXT NOT NULL,
            description_ru TEXT NOT NULL,
            price REAL NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        
        # Stocks Table
        await db.execute("""
        CREATE TABLE IF NOT EXISTS stocks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_id INTEGER NOT NULL,
            data TEXT NOT NULL,
            is_sold INTEGER DEFAULT 0,
            sold_to INTEGER DEFAULT NULL,
            sold_at TIMESTAMP DEFAULT NULL,
            FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
        );
        """)
        
        # Orders Table
        await db.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            product_id INTEGER NOT NULL,
            stock_id INTEGER NOT NULL,
            price_paid REAL NOT NULL,
            purchased_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            stock_data TEXT NOT NULL,
            product_name_ar TEXT NOT NULL,
            product_name_en TEXT NOT NULL,
            product_name_ru TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(user_id)
        );
        """)
        
        # Payments Table
        await db.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            amount REAL NOT NULL,
            payment_method TEXT NOT NULL,
            status TEXT DEFAULT 'pending',
            transaction_id TEXT UNIQUE NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        
        # Settings Table
        await db.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        """)
        
        # User Discounts Table
        await db.execute("""
        CREATE TABLE IF NOT EXISTS user_discounts (
            user_id INTEGER PRIMARY KEY,
            discount_percent REAL NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(user_id) ON DELETE CASCADE
        );
        """)
        
        # Seed settings if they don't exist
        default_settings = {
            'support_username': '',
            'referral_bonus_percent': '10',
            'force_join_channels': '',  # comma separated e.g. "@channel1,@channel2"
            'news_channel': '',
            'stars_rate': '0.02',       # 1 Star = 0.02 USD
            'stars_enabled': '1',
            'crypto_addr_usdt': '0x89846777ea91dee2b25f0fcbf54884a4f79923d8',
            'crypto_addr_ltc': 'LbEuNY2o5ePVyd7dqE4dTyNToAPDtcYMXR',
            'crypto_addr_ton': 'UQC8zbAwkf9-f8SzyYYITLU8Et4g-Cf7ffyQJIhip9nupHGo',
            'bscscan_api_key': '',
            'blockcypher_api_key': '',
            'toncenter_api_key': '',
            'store_name': 'Digital Store'
        }
        for key, val in default_settings.items():
            await db.execute("INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?);", (key, val))
            
        await db.commit()

# Setting Helpers
async def get_setting(key, default=""):
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute("SELECT value FROM settings WHERE key = ?;", (key,)) as cursor:
            row = await cursor.fetchone()
            return row[0] if row else default

async def set_setting(key, value):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?);", (key, str(value)))
        await db.commit()

# User Helpers
async def get_user(user_id):
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users WHERE user_id = ?;", (user_id,)) as cursor:
            return await cursor.fetchone()

async def create_user(user_id, username, first_name, referred_by=None):
    ref_code = str(uuid.uuid4())[:8]
    async with aiosqlite.connect(DB_NAME) as db:
        # Check if user already exists
        async with db.execute("SELECT user_id FROM users WHERE user_id = ?;", (user_id,)) as cursor:
            if await cursor.fetchone():
                return
        
        # Verify if referred_by user exists
        ref_by_id = None
        if referred_by:
            async with db.execute("SELECT user_id FROM users WHERE user_id = ?;", (referred_by,)) as cursor:
                if await cursor.fetchone() and referred_by != user_id:
                    ref_by_id = referred_by
                    
        await db.execute(
            "INSERT INTO users (user_id, username, first_name, referred_by, referral_code) VALUES (?, ?, ?, ?, ?);",
            (user_id, username, first_name, ref_by_id, ref_code)
        )
        await db.commit()

async def get_user_by_ref_code(ref_code):
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM users WHERE referral_code = ?;", (ref_code,)) as cursor:
            return await cursor.fetchone()

async def get_referral_count(user_id):
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute("SELECT COUNT(*) FROM users WHERE referred_by = ?;", (user_id,)) as cursor:
            row = await cursor.fetchone()
            return row[0] if row else 0

async def update_user_lang(user_id, lang):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE users SET language = ? WHERE user_id = ?;", (lang, user_id))
        await db.commit()

async def update_user_balance(user_id, amount):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?;", (amount, user_id))
        await db.commit()

# Product Helpers
async def add_product(name_ar, name_en, name_ru, description_ar, description_en, description_ru, price):
    async with aiosqlite.connect(DB_NAME) as db:
        cursor = await db.execute(
            "INSERT INTO products (name_ar, name_en, name_ru, description_ar, description_en, description_ru, price) VALUES (?, ?, ?, ?, ?, ?, ?);",
            (name_ar, name_en, name_ru, description_ar, description_en, description_ru, price)
        )
        product_id = cursor.lastrowid
        await db.commit()
        return product_id

async def update_product(product_id, name_ar, name_en, name_ru, description_ar, description_en, description_ru, price):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute(
            "UPDATE products SET name_ar = ?, name_en = ?, name_ru = ?, description_ar = ?, description_en = ?, description_ru = ?, price = ? WHERE id = ?;",
            (name_ar, name_en, name_ru, description_ar, description_en, description_ru, price, product_id)
        )
        await db.commit()

async def delete_product(product_id):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("DELETE FROM products WHERE id = ?;", (product_id,))
        await db.commit()

async def get_products():
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM products;") as cursor:
            return await cursor.fetchall()

async def get_product(product_id):
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM products WHERE id = ?;", (product_id,)) as cursor:
            return await cursor.fetchone()

# Stock Helpers
async def add_stock(product_id, data):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("INSERT INTO stocks (product_id, data) VALUES (?, ?);", (product_id, data))
        await db.commit()

async def bulk_add_stock(product_id, items):
    async with aiosqlite.connect(DB_NAME) as db:
        params = [(product_id, item) for item in items if item.strip()]
        await db.executemany("INSERT INTO stocks (product_id, data) VALUES (?, ?);", params)
        await db.commit()

async def get_stock_count(product_id):
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute("SELECT COUNT(*) FROM stocks WHERE product_id = ? AND is_sold = 0;", (product_id,)) as cursor:
            row = await cursor.fetchone()
            return row[0] if row else 0

# Purchase Helpers
async def buy_product(user_id, product_id):
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        
        # Get product info
        async with db.execute("SELECT * FROM products WHERE id = ?;", (product_id,)) as cursor:
            product = await cursor.fetchone()
            if not product:
                raise Exception("Product not found")
        
        # Get user info
        async with db.execute("SELECT balance FROM users WHERE user_id = ?;", (user_id,)) as cursor:
            user = await cursor.fetchone()
            if not user:
                raise Exception("User not found")
                
        # Check user discount
        async with db.execute("SELECT discount_percent FROM user_discounts WHERE user_id = ?;", (user_id,)) as cursor:
            discount_row = await cursor.fetchone()
            discount_percent = discount_row[0] if discount_row else 0.0
            
        final_price = product['price'] * (1 - discount_percent / 100)
        
        if user['balance'] < final_price:
            raise Exception("Insufficient balance")
            
        # Get one unsold stock item
        async with db.execute("SELECT * FROM stocks WHERE product_id = ? AND is_sold = 0 LIMIT 1;", (product_id,)) as cursor:
            stock = await cursor.fetchone()
            if not stock:
                raise Exception("Out of stock")
                
        # Begin transaction updates
        # Deduct balance
        await db.execute("UPDATE users SET balance = balance - ? WHERE user_id = ?;", (final_price, user_id))
        
        # Mark stock as sold
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        await db.execute(
            "UPDATE stocks SET is_sold = 1, sold_to = ?, sold_at = ? WHERE id = ?;",
            (user_id, now, stock['id'])
        )
        
        # Create order
        await db.execute(
            """INSERT INTO orders (user_id, product_id, stock_id, price_paid, purchased_at, stock_data, product_name_ar, product_name_en, product_name_ru)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);""",
            (user_id, product['id'], stock['id'], final_price, now, stock['data'], product['name_ar'], product['name_en'], product['name_ru'])
        )
        
        await db.commit()
        return stock['data'], final_price

async def get_orders(user_id):
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM orders WHERE user_id = ? ORDER BY id DESC;", (user_id,)) as cursor:
            return await cursor.fetchall()

# Payments / Deposits Helpers
async def create_payment(user_id, amount, payment_method, transaction_id):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute(
            "INSERT INTO payments (user_id, amount, payment_method, transaction_id) VALUES (?, ?, ?, ?);",
            (user_id, amount, payment_method, transaction_id)
        )
        await db.commit()

async def get_payment(transaction_id):
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM payments WHERE transaction_id = ?;", (transaction_id,)) as cursor:
            return await cursor.fetchone()

async def complete_payment(transaction_id):
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        
        # Get payment
        async with db.execute("SELECT * FROM payments WHERE transaction_id = ? AND status = 'pending';", (transaction_id,)) as cursor:
            payment = await cursor.fetchone()
            if not payment:
                return None  # already processed or doesn't exist
        
        # Mark payment as completed
        await db.execute("UPDATE payments SET status = 'completed' WHERE transaction_id = ?;", (transaction_id,))
        
        user_id = payment['user_id']
        amount = payment['amount']
        
        # Credit user balance
        await db.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?;", (amount, user_id))
        
        # Check if user has a referrer to award bonus
        async with db.execute("SELECT referred_by FROM users WHERE user_id = ?;", (user_id,)) as cursor:
            user_row = await cursor.fetchone()
            referrer_id = user_row['referred_by'] if user_row else None
            
        referrer_notification = None
        if referrer_id:
            # Read referral bonus percent
            async with db.execute("SELECT value FROM settings WHERE key = 'referral_bonus_percent';") as cursor:
                sett_row = await cursor.fetchone()
                bonus_pct = float(sett_row[0]) if sett_row else 10.0
                
            bonus_amount = amount * (bonus_pct / 100.0)
            if bonus_amount > 0:
                await db.execute(
                    "UPDATE users SET balance = balance + ?, referral_balance_earned = referral_balance_earned + ? WHERE user_id = ?;",
                    (bonus_amount, bonus_amount, referrer_id)
                )
                referrer_notification = {
                    'referrer_id': referrer_id,
                    'bonus': bonus_amount,
                    'referee_id': user_id
                }
                
        await db.commit()
        return {
            'user_id': user_id,
            'amount': amount,
            'referrer_notif': referrer_notification
        }

async def reject_payment(transaction_id):
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM payments WHERE transaction_id = ? AND status = 'pending';", (transaction_id,)) as cursor:
            payment = await cursor.fetchone()
            if not payment:
                return None
        await db.execute("UPDATE payments SET status = 'rejected' WHERE transaction_id = ?;", (transaction_id,))
        await db.commit()
        return payment

async def get_all_users():
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT user_id, language FROM users;") as cursor:
            return await cursor.fetchall()

async def get_pending_blockchain_payments():
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM payments WHERE status = 'pending' AND payment_method LIKE 'blockchain_%';"
        ) as cursor:
            return await cursor.fetchall()

async def get_all_pending_payments():
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute(
            "SELECT * FROM payments WHERE status = 'pending' ORDER BY id DESC;"
        ) as cursor:
            return await cursor.fetchall()

async def is_payment_processed(payment_method):
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute(
            "SELECT id FROM payments WHERE payment_method = ? AND status IN ('completed', 'rejected');", 
            (payment_method,)
        ) as cursor:
            return await cursor.fetchone() is not None

async def get_payment_by_method(payment_method):
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        async with db.execute("SELECT * FROM payments WHERE payment_method = ?;", (payment_method,)) as cursor:
            return await cursor.fetchone()

# User Discounts Helpers
async def get_user_discount(user_id):
    async with aiosqlite.connect(DB_NAME) as db:
        async with db.execute("SELECT discount_percent FROM user_discounts WHERE user_id = ?;", (user_id,)) as cursor:
            row = await cursor.fetchone()
            return row[0] if row else 0.0

async def set_user_discount(user_id, percent):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute(
            "INSERT OR REPLACE INTO user_discounts (user_id, discount_percent) VALUES (?, ?);",
            (user_id, percent)
        )
        await db.commit()

async def delete_user_discount(user_id):
    async with aiosqlite.connect(DB_NAME) as db:
        await db.execute("DELETE FROM user_discounts WHERE user_id = ?;", (user_id,))
        await db.commit()

async def get_all_user_discounts():
    async with aiosqlite.connect(DB_NAME) as db:
        db.row_factory = aiosqlite.Row
        query = """
            SELECT ud.user_id, ud.discount_percent, u.username, u.first_name 
            FROM user_discounts ud 
            LEFT JOIN users u ON ud.user_id = u.user_id
            ORDER BY ud.discount_percent DESC;
        """
        async with db.execute(query) as cursor:
            return await cursor.fetchall()
