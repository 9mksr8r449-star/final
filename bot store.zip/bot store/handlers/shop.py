from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from database import (
    get_products, get_product, get_stock_count, buy_product, get_user, get_setting,
    get_user_discount
)
from localization import get_text
import keyboards
import logging

logger = logging.getLogger(__name__)
router = Router()

async def show_products_list(message_or_callback, lang='en'):
    products = await get_products()
    if not products:
        text = get_text('shop_empty', lang)
        if isinstance(message_or_callback, CallbackQuery):
            await message_or_callback.message.edit_text(text, reply_markup=keyboards.get_products_keyboard([], lang))
        else:
            await message_or_callback.answer(text)
        return
        
    text = get_text('shop_title', lang)
    kb = keyboards.get_products_keyboard(products, lang)
    
    if isinstance(message_or_callback, CallbackQuery):
        await message_or_callback.message.edit_text(text, reply_markup=kb, parse_mode="Markdown")
    else:
        await message_or_callback.answer(text, reply_markup=kb, parse_mode="Markdown")

@router.message(F.text.in_([
    get_text('btn_shop', 'en'),
    get_text('btn_shop', 'ar'),
    get_text('btn_shop', 'ru')
]))
async def cmd_shop(message: Message, lang='en'):
    await show_products_list(message, lang)

@router.callback_query(F.data == "shop_list")
async def cb_shop_list(callback: CallbackQuery, lang='en'):
    await show_products_list(callback, lang)
    await callback.answer()

@router.callback_query(F.data.startswith("prod_view_"))
async def cb_product_view(callback: CallbackQuery, lang='en'):
    product_id = int(callback.data.replace("prod_view_", ""))
    product = await get_product(product_id)
    
    if not product:
        await callback.answer("Product not found.")
        return
        
    stock_count = await get_stock_count(product_id)
    has_stock = stock_count > 0
    
    name = product[f'name_{lang}'] or product['name_en']
    desc = product[f'description_{lang}'] or product['description_en']
    
    # Check user discount
    user_id = callback.from_user.id
    discount_pct = await get_user_discount(user_id)
    if discount_pct > 0:
        price_val = product['price'] * (1 - discount_pct / 100)
        if lang == 'ar':
            price_str = f"~~${product['price']:.2f}~~ *${price_val:.2f} USD* (خصم {discount_pct:.0f}%)"
        elif lang == 'ru':
            price_str = f"~~${product['price']:.2f}~~ *${price_val:.2f} USD* (Скидка {discount_pct:.0f}%)"
        else:
            price_str = f"~~${product['price']:.2f}~~ *${price_val:.2f} USD* ({discount_pct:.0f}% Discount)"
    else:
        price_str = f"`${product['price']:.2f} USD`"
        
    text = get_text(
        'product_details',
        lang,
        name=name,
        desc=desc,
        price=price_str,
        stock=stock_count
    )
    
    kb = keyboards.get_product_view_keyboard(product_id, has_stock, lang)
    await callback.message.edit_text(text, reply_markup=kb, parse_mode="Markdown")
    await callback.answer()

@router.callback_query(F.data.startswith("prod_buy_"))
async def cb_product_buy(callback: CallbackQuery, bot: Bot, lang='en'):
    product_id = int(callback.data.replace("prod_buy_", ""))
    user_id = callback.from_user.id
    
    # Refresh user balance and product price
    db_user = await get_user(user_id)
    product = await get_product(product_id)
    
    if not product:
        await callback.answer("Product not found.")
        return
        
    if not db_user:
        await callback.answer("User profile error.")
        return
        
    # Get user discount and calculate final price
    discount_pct = await get_user_discount(user_id)
    price_to_pay = product['price'] * (1 - discount_pct / 100)
    
    if db_user['balance'] < price_to_pay:
        # Alert insufficient balance
        await callback.message.edit_text(
            get_text('insufficient_balance', lang, balance=db_user['balance'], price=price_to_pay),
            reply_markup=keyboards.get_product_view_keyboard(product_id, True, lang),
            parse_mode="Markdown"
        )
        await callback.answer()
        return
        
    try:
        # Perform buy transaction
        stock_data, price_paid = await buy_product(user_id, product_id)
        
        prod_name = product[f'name_{lang}'] or product['name_en']
        
        # Purchase success message
        success_text = get_text(
            'purchase_success',
            lang,
            name=prod_name,
            price=price_paid,
            data=stock_data
        )
        
        await callback.message.edit_text(success_text, parse_mode="Markdown")
        await callback.answer("Success!")
                
        # Publish sale to news_channel if set
        news_channel = await get_setting('news_channel', '')
        if news_channel:
            try:
                import html
                from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
                bot_info = await bot.get_me()
                bot_username = bot_info.username
                prod_name_en = html.escape(product['name_en'])
                sale_text = (
                    f"⚡️ <b>NEW PURCHASE</b> ⚡️\n"
                    f"──────────────────\n"
                    f"🛍 <b>Product:</b> <code>{prod_name_en}</code>\n"
                    f"💵 <b>Amount Paid:</b> <code>${price_paid:.2f} USD</code>\n"
                    f"📅 <b>Status:</b> <code>Delivered Successfully</code>\n"
                    f"──────────────────\n"
                    f"👉 <i>Want to buy? Visit our bot:</i> @{bot_username}"
                )
                kb = InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="🛍️ Shop Now", url=f"https://t.me/{bot_username}")]
                ])
                await bot.send_message(chat_id=news_channel, text=sale_text, parse_mode="HTML", reply_markup=kb)
            except Exception as e:
                logger.error(f"Failed to log sale to news channel: {e}")
                
    except Exception as e:
        logger.error(f"Purchase failed: {e}")
        # Send stock error or balance error
        err_msg = str(e)
        if "Out of stock" in err_msg:
            await callback.message.edit_text(
                get_text('out_of_stock', lang),
                reply_markup=keyboards.get_product_view_keyboard(product_id, False, lang)
            )
        else:
            await callback.message.edit_text(
                f"❌ Error occurred: {err_msg}",
                reply_markup=keyboards.get_product_view_keyboard(product_id, True, lang)
            )
        await callback.answer()
