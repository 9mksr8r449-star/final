from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery
from database import create_user, get_user, update_user_lang, get_referral_count, get_user_by_ref_code, get_setting, get_orders
from localization import get_text
import keyboards
import logging

logger = logging.getLogger(__name__)
router = Router()

@router.message(Command("start"))
async def cmd_start(message: Message, command: CommandObject, bot: Bot, db_user=None, is_admin=False, lang='en'):
    user_id = message.from_user.id
    first_name = message.from_user.first_name
    username = message.from_user.username or ""
    
    # Force Join Channel check (if enabled in settings)
    force_channels_str = await get_setting('force_join_channels', '')
    if force_channels_str:
        force_channels = [c.strip() for c in force_channels_str.split(",") if c.strip()]
        unjoined_channels = []
        for channel in force_channels:
            try:
                member = await bot.get_chat_member(chat_id=channel, user_id=user_id)
                if member.status in ['left', 'kicked']:
                    unjoined_channels.append(channel)
            except Exception as e:
                logger.warning(f"Could not verify join for channel {channel}: {e}")
                
        if unjoined_channels:
            channels_list = "\n".join(unjoined_channels)
            await message.answer(
                get_text('force_join_msg', lang, channels=channels_list)
            )
            return

    # Check start parameters for referral code
    if not db_user:
        referred_by = None
        if command.args and command.args.startswith("ref_"):
            ref_code = command.args.replace("ref_", "")
            referrer = await get_user_by_ref_code(ref_code)
            if referrer:
                referred_by = referrer['user_id']
                logger.info(f"User {user_id} referred by {referred_by}")
        await create_user(user_id, username, first_name, referred_by=referred_by)
        db_user = await get_user(user_id)
        if db_user:
            lang = db_user['language']

    # Fetch referrer name
    ref_by_name = "None"
    if db_user and db_user['referred_by']:
        referrer_profile = await get_user(db_user['referred_by'])
        if referrer_profile:
            ref_by_name = referrer_profile['first_name']
            
    ref_count = await get_referral_count(user_id)
    balance = db_user['balance'] if db_user else 0.0
    
    store_name = await get_setting('store_name', 'Digital Store')
    welcome_text = get_text(
        'welcome', 
        lang, 
        name=first_name, 
        balance=balance, 
        referred_by=ref_by_name, 
        ref_count=ref_count,
        store_name=store_name
    )
    
    await message.answer(
        welcome_text,
        reply_markup=keyboards.get_main_menu(lang, is_admin),
        parse_mode="Markdown"
    )

@router.message(F.text.in_([
    get_text('btn_language', 'en'),
    get_text('btn_language', 'ar'),
    get_text('btn_language', 'ru')
]))
async def show_language_menu(message: Message, lang='en'):
    await message.answer(
        get_text('select_lang', lang),
        reply_markup=keyboards.get_language_keyboard()
    )

@router.callback_query(F.data.startswith("set_lang_"))
async def process_set_lang(callback: CallbackQuery, is_admin=False):
    lang_code = callback.data.replace("set_lang_", "")
    user_id = callback.from_user.id
    await update_user_lang(user_id, lang_code)
    
    await callback.answer(get_text('lang_updated', lang_code))
    
    db_user = await get_user(user_id)
    ref_by_name = "None"
    if db_user and db_user['referred_by']:
        referrer_profile = await get_user(db_user['referred_by'])
        if referrer_profile:
            ref_by_name = referrer_profile['first_name']
            
    ref_count = await get_referral_count(user_id)
    balance = db_user['balance'] if db_user else 0.0
    
    store_name = await get_setting('store_name', 'Digital Store')
    welcome_text = get_text(
        'welcome', 
        lang_code, 
        name=callback.from_user.first_name, 
        balance=balance, 
        referred_by=ref_by_name, 
        ref_count=ref_count,
        store_name=store_name
    )
    
    await callback.message.answer(
        welcome_text,
        reply_markup=keyboards.get_main_menu(lang_code, is_admin),
        parse_mode="Markdown"
    )
    await callback.message.delete()

@router.message(F.text.in_([
    get_text('btn_referral', 'en'),
    get_text('btn_referral', 'ar'),
    get_text('btn_referral', 'ru')
]))
async def show_referral_menu(message: Message, bot: Bot, db_user, lang='en'):
    user_id = message.from_user.id
    ref_code = db_user['referral_code']
    ref_count = await get_referral_count(user_id)
    ref_earned = db_user['referral_balance_earned']
    
    bot_info = await bot.get_me()
    bot_username = bot_info.username
    ref_link = f"https://t.me/{bot_username}?start=ref_{ref_code}"
    
    bonus_percent = await get_setting('referral_bonus_percent', '10')
    
    msg_text = get_text(
        'referral_msg',
        lang,
        bonus=bonus_percent,
        count=ref_count,
        earned=ref_earned,
        link=ref_link
    )
    
    await message.answer(msg_text, parse_mode="Markdown", disable_web_page_preview=True)

@router.message(F.text.in_([
    get_text('btn_my_orders', 'en'),
    get_text('btn_my_orders', 'ar'),
    get_text('btn_my_orders', 'ru')
]))
async def show_orders_menu(message: Message, lang='en'):
    user_id = message.from_user.id
    orders = await get_orders(user_id)
    
    if not orders:
        await message.answer(get_text('my_orders_empty', lang))
        return
        
    await message.answer(get_text('my_orders_title', lang), parse_mode="Markdown")
    
    # Display products bought. Limit to recent 10 to keep it manageable.
    for order in orders[:10]:
        prod_name = order[f'product_name_{lang}'] or order['product_name_en']
        order_text = get_text(
            'order_item',
            lang,
            id=order['id'],
            name=prod_name,
            price=order['price_paid'],
            date=order['purchased_at'],
            data=order['stock_data']
        )
        await message.answer(order_text, parse_mode="Markdown")
