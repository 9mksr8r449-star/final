from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from database import (
    get_products, get_product, add_product, update_product, delete_product,
    add_stock, bulk_add_stock, get_stock_count, get_setting, set_setting, get_all_users,
    get_user, get_referral_count, get_all_pending_payments
)
from localization import get_text
from handlers.states import ProductStates, StockStates, AdminStates
import keyboards
import config
import logging

logger = logging.getLogger(__name__)
router = Router()

def is_user_admin(user_id):
    return user_id in config.ADMIN_IDS

@router.message(F.text.in_([
    get_text('btn_admin_panel', 'en'),
    get_text('btn_admin_panel', 'ar'),
    get_text('btn_admin_panel', 'ru'),
    "🔧 Admin Panel",
    "Admin Panel"
]))
async def cmd_admin_panel(message: Message, lang='en'):
    if not is_user_admin(message.from_user.id):
        return
        
    await message.answer(
        get_text('admin_panel', lang),
        reply_markup=keyboards.get_admin_reply_keyboard(lang)
    )

@router.callback_query(F.data == "admin_menu")
async def cb_admin_menu(callback: CallbackQuery, lang='en'):
    if not is_user_admin(callback.from_user.id):
        await callback.answer("Not authorized.")
        return
        
    # Delete current inline message since ReplyKeyboardMarkup cannot be edited in
    await callback.message.delete()
    await callback.message.answer(
        get_text('admin_panel', lang),
        reply_markup=keyboards.get_admin_reply_keyboard(lang)
    )
    await callback.answer()

@router.message(F.text == "📦 Manage Products")
async def msg_admin_manage_products(message: Message, lang='en'):
    if not is_user_admin(message.from_user.id):
        return
        
    products = await get_products()
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="➕ Add Product", callback_data="admin_prod_add")
    for prod in products:
        name = prod['name_en']
        builder.button(text=f"✏️ {name} (${prod['price']:.2f})", callback_data=f"admin_prod_view_{prod['id']}")
    builder.button(text="🔙 Back to Admin Menu", callback_data="admin_menu")
    builder.adjust(1)
    
    await message.answer(
        "📦 *Product Management*\nSelect a product to edit/delete or add a new one:",
        reply_markup=builder.as_markup(),
        parse_mode="Markdown"
    )

@router.message(F.text.in_(["📥 Add Stock", "📦 Bulk Add Stock"]))
async def msg_admin_stock_select_prod(message: Message, state: FSMContext):
    if not is_user_admin(message.from_user.id):
        return
    action = "admin_add_stock" if message.text == "📥 Add Stock" else "admin_bulk_stock"
    products = await get_products()
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    for prod in products:
        builder.button(text=f"{prod['name_en']}", callback_data=f"admin_stk_{action.split('_')[1]}_{prod['id']}")
    builder.button(text="🔙 Back to Admin Menu", callback_data="admin_menu")
    builder.adjust(1)
    
    await message.answer(
        "📥 *Select Product for Stock adding*:",
        reply_markup=builder.as_markup(),
        parse_mode="Markdown"
    )

@router.message(F.text == "⏳ Pending Deposits")
async def msg_admin_pending_deposits(message: Message):
    if not is_user_admin(message.from_user.id):
        return
        
    pending_payments = await get_all_pending_payments()
    if not pending_payments:
        await message.answer("📭 No pending deposits at the moment.")
        return
        
    await message.answer(f"⏳ Found {len(pending_payments)} pending deposit request(s):")
    
    for payment in pending_payments:
        user_id = payment['user_id']
        user_info = f"`{user_id}`"
        db_user = await get_user(user_id)
        if db_user:
            user_info = db_user['first_name']
            if db_user['username']:
                user_info += f" (@{db_user['username']})"
            user_info += f" (`{user_id}`)"
            
        method_str = payment['payment_method']
        if method_str.startswith("blockchain_"):
            parts = method_str.split("_")
            coin = parts[1]
            txid = "_".join(parts[2:])
            method_desc = f"🪙 Crypto: `{coin}`\n🔗 TxID: `{txid}`"
        elif method_str == "telegram_stars":
            method_desc = "⭐️ Telegram Stars"
        else:
            method_desc = f"`{method_str}`"
            
        msg_text = (
            f"⏳ *Pending Deposit Request*\n\n"
            f"👤 *User:* {user_info}\n"
            f"💵 *Amount:* `${payment['amount']:.2f} USD`\n"
            f"ℹ️ *Method:* {method_desc}\n"
            f"📅 *Date:* `{payment['created_at']}`\n\n"
            f"Transaction ID: `{payment['transaction_id']}`"
        )
        kb = keyboards.get_admin_payment_approval_keyboard(payment['transaction_id'])
        await message.answer(msg_text, reply_markup=kb, parse_mode="Markdown")

@router.message(F.text.in_([
    "📢 Channels Settings", 
    "🎧 Support Settings", 
    "💳 Charge Section", 
    "👥 Referral System",
    "🔑 API Keys Settings"
]))
async def msg_admin_settings_menu(message: Message):
    if not is_user_admin(message.from_user.id):
        return
    
    mapping = {
        "📢 Channels Settings": "admin_channels",
        "🎧 Support Settings": "admin_support_settings",
        "💳 Charge Section": "admin_charge_settings",
        "👥 Referral System": "admin_referral_settings",
        "🔑 API Keys Settings": "admin_api_keys_settings"
    }
    menu = mapping[message.text]
    
    text = ""
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    
    if menu == "admin_channels":
        force_join = await get_setting("force_join_channels", "None")
        news_ch = await get_setting("news_channel", "None")
        text = (
            f"📢 *Channel Settings*\n\n"
            f"🔗 *Force Join:* `{force_join}`\n"
            f"📣 *News Channel:* `{news_ch}`"
        )
        builder.button(text="✍️ Set Force Join Channels", callback_data="admin_set_force_join")
        builder.button(text="✍️ Set News Channel", callback_data="admin_set_news_ch")
        
    elif menu == "admin_support_settings":
        support = await get_setting("support_username", "None")
        text = (
            f"🎧 *Support Settings*\n\n"
            f"👤 *Support Handle:* `{support}`"
        )
        builder.button(text="✍️ Edit Support Handle", callback_data="admin_set_support")
        
    elif menu == "admin_charge_settings":
        stars = await get_setting("stars_enabled", "1")
        stars_rate = await get_setting("stars_rate", "0.02")
        usdt_addr = await get_setting("crypto_addr_usdt", "0x89846777ea91dee2b25f0fcbf54884a4f79923d8")
        ltc_addr = await get_setting("crypto_addr_ltc", "LbEuNY2o5ePVyd7dqE4dTyNToAPDtcYMXR")
        ton_addr = await get_setting("crypto_addr_ton", "UQC8zbAwkf9-f8SzyYYITLU8Et4g-Cf7ffyQJIhip9nupHGo")
        
        s_status = "✅ Enabled" if stars == "1" else "❌ Disabled"
        
        text = (
            f"💳 *Deposit Settings*\n\n"
            f"⭐️ *Telegram Stars:* {s_status}\n"
            f"💱 *Stars Exchange Rate:* 1 Star = `{stars_rate}` USD\n\n"
            f"🪙 *USDT BEP20 Address:* `{usdt_addr}`\n"
            f"🪙 *LTC Address:* `{ltc_addr}`\n"
            f"🪙 *TON Address:* `{ton_addr}`"
        )
        builder.button(text="Toggle Telegram Stars", callback_data="admin_toggle_stars")
        builder.button(text="Set Stars Exchange Rate", callback_data="admin_set_stars_rate")
        builder.button(text="✍️ Set USDT BEP20 Address", callback_data="admin_set_crypto_addr_usdt")
        builder.button(text="✍️ Set LTC Address", callback_data="admin_set_crypto_addr_ltc")
        builder.button(text="✍️ Set TON Address", callback_data="admin_set_crypto_addr_ton")
        
    elif menu == "admin_referral_settings":
        pct = await get_setting("referral_bonus_percent", "10")
        text = (
            f"👥 *Referral System Settings*\n\n"
            f"💰 *Bonus Percentage:* `{pct}%` of referral deposits"
        )
        builder.button(text="✍️ Edit Bonus Percentage", callback_data="admin_set_ref_pct")
        
    elif menu == "admin_api_keys_settings":
        bscscan_key = (await get_setting("bscscan_api_key", "")) or "None"
        blockcypher_key = (await get_setting("blockcypher_api_key", "")) or "None"
        toncenter_key = (await get_setting("toncenter_api_key", "")) or "None"
        
        text = (
            f"🔑 *API Keys Configuration*\n\n"
            f"🔸 *BscScan API Key:* `{bscscan_key}`\n"
            f"🔗 [Get BscScan Key](https://bscscan.com/myapikey)\n\n"
            f"🪙 *Blockcypher API Token:* `{blockcypher_key}`\n"
            f"🔗 [Get Blockcypher Token](https://accounts.blockcypher.com/)\n\n"
            f"💎 *Toncenter API Key:* `{toncenter_key}`\n"
            f"🔗 [Get Toncenter Key](https://t.me/toncenter)"
        )
        builder.button(text="✍️ Set BscScan API Key", callback_data="admin_set_bscscan_api_key")
        builder.button(text="✍️ Set Blockcypher API Token", callback_data="admin_set_blockcypher_api_key")
        builder.button(text="✍️ Set Toncenter API Key", callback_data="admin_set_toncenter_api_key")
        
    builder.button(text="🔙 Back to Admin Menu", callback_data="admin_menu")
    builder.adjust(1)
    
    await message.answer(text, reply_markup=builder.as_markup(), parse_mode="Markdown")

@router.message(F.text == "📣 Broadcast")
async def msg_admin_broadcast_trigger(message: Message, state: FSMContext):
    if not is_user_admin(message.from_user.id):
        return
    await state.set_state(AdminStates.waiting_for_broadcast)
    await message.answer("📣 Send the message you want to broadcast to *all users* (can contain formatting or markdown):")

@router.message(F.text == "🔙 Back to Main Menu")
async def msg_admin_back_to_user_menu(message: Message):
    if not is_user_admin(message.from_user.id):
        return
    user_id = message.from_user.id
    db_user = await get_user(user_id)
    lang = db_user['language'] if db_user else 'en'
    
    ref_by_name = "None"
    if db_user and db_user['referred_by']:
        referrer_profile = await get_user(db_user['referred_by'])
        if referrer_profile:
            ref_by_name = referrer_profile['first_name']
            
    ref_count = await get_referral_count(user_id)
    balance = db_user['balance'] if db_user else 0.0
    
    store_name = await get_setting('store_name', 'Digital Store')
    welcome_text = get_text(
        'welcome', 
        lang, 
        name=message.from_user.first_name, 
        balance=balance, 
        referred_by=ref_by_name, 
        ref_count=ref_count,
        store_name=store_name
    )
    
    await message.answer(
        welcome_text,
        reply_markup=keyboards.get_main_menu(lang, is_admin=True),
        parse_mode="Markdown"
    )

# --- Manage Products ---
@router.callback_query(F.data == "admin_manage_products")
async def cb_admin_manage_products(callback: CallbackQuery, lang='en'):
    if not is_user_admin(callback.from_user.id):
        return
        
    products = await get_products()
    
    # Inline buttons for managing products
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    
    builder.button(text="➕ Add Product", callback_data="admin_prod_add")
    
    for prod in products:
        name = prod['name_en']
        builder.button(text=f"✏️ {name} (${prod['price']:.2f})", callback_data=f"admin_prod_view_{prod['id']}")
        
    builder.button(text="🔙 Back to Admin Menu", callback_data="admin_menu")
    builder.adjust(1)
    
    await callback.message.edit_text(
        "📦 *Product Management*\nSelect a product to edit/delete or add a new one:",
        reply_markup=builder.as_markup(),
        parse_mode="Markdown"
    )
    await callback.answer()

@router.callback_query(F.data.startswith("admin_prod_view_"))
async def cb_admin_prod_view(callback: CallbackQuery, lang='en'):
    if not is_user_admin(callback.from_user.id):
        return
        
    prod_id = int(callback.data.replace("admin_prod_view_", ""))
    product = await get_product(prod_id)
    if not product:
        await callback.answer("Product not found.")
        return
        
    stock = await get_stock_count(prod_id)
    
    text = (
        f"📋 *Product Details (Admin)*\n\n"
        f"🇬🇧 *Name EN:* {product['name_en']}\n"
        f"🇸🇦 *Name AR:* {product['name_ar']}\n"
        f"🇷🇺 *Name RU:* {product['name_ru']}\n\n"
        f"🇬🇧 *Desc EN:* {product['description_en']}\n"
        f"🇸🇦 *Desc AR:* {product['description_ar']}\n"
        f"🇷🇺 *Desc RU:* {product['description_ru']}\n\n"
        f"💵 *Price:* ${product['price']:.2f} USD\n"
        f"📦 *Stock Count:* {stock} items available"
    )
    
    await callback.message.edit_text(
        text,
        reply_markup=keyboards.get_admin_product_edit_keyboard(prod_id),
        parse_mode="Markdown"
    )
    await callback.answer()

@router.callback_query(F.data.startswith("admin_prod_del_"))
async def cb_admin_prod_del(callback: CallbackQuery, lang='en'):
    if not is_user_admin(callback.from_user.id):
        return
    prod_id = int(callback.data.replace("admin_prod_del_", ""))
    await delete_product(prod_id)
    await callback.answer("Product deleted successfully!", show_alert=True)
    await cb_admin_manage_products(callback, lang)

# --- Add Product FSM ---
@router.callback_query(F.data == "admin_prod_add")
async def cb_admin_prod_add(callback: CallbackQuery, state: FSMContext):
    if not is_user_admin(callback.from_user.id):
        return
    await state.set_state(ProductStates.waiting_for_name)
    await callback.message.answer("✏️ Enter Product Name:")
    await callback.answer()

@router.message(ProductStates.waiting_for_name)
async def add_prod_name(message: Message, state: FSMContext):
    await state.update_data(name=message.text.strip())
    await state.set_state(ProductStates.waiting_for_desc)
    await message.answer("✏️ Enter Product Description:")

@router.message(ProductStates.waiting_for_desc)
async def add_prod_desc(message: Message, state: FSMContext):
    await state.update_data(desc=message.text.strip())
    await state.set_state(ProductStates.waiting_for_price)
    await message.answer("✏️ Enter Product Price in *USD* (e.g. 5.50):")

@router.message(ProductStates.waiting_for_price)
async def add_prod_price(message: Message, state: FSMContext, bot: Bot, lang='en'):
    try:
        price = float(message.text)
        if price < 0:
            raise ValueError()
    except ValueError:
        await message.answer("❌ Invalid price. Enter a positive decimal number:")
        return
        
    data = await state.get_data()
    await state.clear()
    
    product_name = data['name']
    product_desc = data['desc']
    
    product_id = await add_product(
        name_ar=product_name,
        name_en=product_name,
        name_ru=product_name,
        description_ar=product_desc,
        description_en=product_desc,
        description_ru=product_desc,
        price=price
    )
    
    await message.answer(
        "✅ Product added successfully!",
        reply_markup=keyboards.get_admin_back_keyboard()
    )
    
    # Broadcast to news channel if configured
    news_channel = await get_setting('news_channel', '')
    if news_channel:
        try:
            import html
            from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
            bot_info = await bot.get_me()
            bot_username = bot_info.username
            escaped_name = html.escape(product_name)
            escaped_desc = html.escape(product_desc)
            announce_text = (
                f"🔥 <b>NEW PRODUCT AVAILABLE</b> 🔥\n"
                f"──────────────────\n"
                f"📦 <b>Name:</b> <code>{escaped_name}</code>\n"
                f"💵 <b>Price:</b> <code>${price:.2f} USD</code>\n\n"
                f"📝 <b>Description:</b>\n"
                f"<i>{escaped_desc}</i>\n"
                f"──────────────────\n"
                f"👉 <i>Get it now:</i> @{bot_username}"
            )
            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🛒 Buy Now", url=f"https://t.me/{bot_username}")]
            ])
            await bot.send_message(chat_id=news_channel, text=announce_text, parse_mode="HTML", reply_markup=kb)
        except Exception as e:
            logger.error(f"Failed to log new product announcement: {e}")

# --- Edit Product FSM ---
# --- Edit Product FSM ---
@router.callback_query(F.data.startswith("admin_edit_fields_"))
async def cb_admin_edit_fields(callback: CallbackQuery, state: FSMContext):
    prod_id = int(callback.data.replace("admin_edit_fields_", ""))
    product = await get_product(prod_id)
    if not product:
        await callback.answer("Product not found.")
        return
        
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    builder.button(text="✏️ Name / الاسم", callback_data=f"admin_edit_spec_{prod_id}_name")
    builder.button(text="✏️ Description / الوصف", callback_data=f"admin_edit_spec_{prod_id}_desc")
    builder.button(text="✏️ Price / السعر", callback_data=f"admin_edit_spec_{prod_id}_price")
    builder.button(text="🔙 Back to Product Details", callback_data=f"admin_prod_view_{prod_id}")
    builder.adjust(1)
    
    await callback.message.edit_text(
        f"✏️ *Editing Product:* {product['name_en']}\nSelect which field you want to edit:",
        reply_markup=builder.as_markup(),
        parse_mode="Markdown"
    )
    await callback.answer()

@router.callback_query(F.data.startswith("admin_edit_spec_"))
async def cb_admin_edit_specific(callback: CallbackQuery, state: FSMContext):
    parts = callback.data.split("_")
    prod_id = int(parts[3])
    field = "_".join(parts[4:])
    
    product = await get_product(prod_id)
    if not product:
        await callback.answer("Product not found.")
        return
        
    await state.update_data(edit_prod_id=prod_id, edit_field=field)
    
    field_labels = {
        "name": "Name / الاسم",
        "desc": "Description / الوصف",
        "price": "Price / السعر"
    }
    
    field_label = field_labels.get(field, field)
    await state.set_state(ProductStates.waiting_for_edit_specific_value)
    
    await callback.message.answer(
        f"✏️ Enter new value for *{field_label}*:"
    )
    await callback.answer()

@router.message(ProductStates.waiting_for_edit_specific_value)
async def process_edit_specific_value(message: Message, state: FSMContext):
    data = await state.get_data()
    prod_id = data.get("edit_prod_id")
    field = data.get("edit_field")
    
    if not prod_id or not field:
        await state.clear()
        await message.answer("❌ Session expired. Try again.")
        return
        
    val = message.text.strip()
    
    product = await get_product(prod_id)
    if not product:
        await state.clear()
        await message.answer("❌ Product not found.")
        return
        
    name_ar = product['name_ar']
    name_en = product['name_en']
    name_ru = product['name_ru']
    description_ar = product['description_ar']
    description_en = product['description_en']
    description_ru = product['description_ru']
    price = product['price']
    
    if field == "name":
        name_ar = val
        name_en = val
        name_ru = val
    elif field == "desc":
        description_ar = val
        description_en = val
        description_ru = val
    elif field == "price":
        try:
            price = float(val)
            if price < 0:
                raise ValueError()
        except ValueError:
            await message.answer("❌ Invalid price. Enter a positive number:")
            return
            
    await state.clear()
    
    await update_product(
        product_id=prod_id,
        name_ar=name_ar,
        name_en=name_en,
        name_ru=name_ru,
        description_ar=description_ar,
        description_en=description_en,
        description_ru=description_ru,
        price=price
    )
    
    await message.answer(
        f"✅ Product updated successfully!",
        reply_markup=keyboards.get_admin_back_keyboard()
    )

# --- Stock Settings ---
@router.callback_query(F.data.in_(["admin_add_stock", "admin_bulk_stock"]))
async def cb_admin_stock_select_prod(callback: CallbackQuery, state: FSMContext):
    action = callback.data
    products = await get_products()
    
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    
    for prod in products:
        builder.button(text=f"{prod['name_en']}", callback_data=f"admin_stk_{action.split('_')[1]}_{prod['id']}")
        
    builder.button(text="🔙 Back to Admin Menu", callback_data="admin_menu")
    builder.adjust(1)
    
    await callback.message.edit_text(
        "📥 *Select Product for Stock adding*:",
        reply_markup=builder.as_markup(),
        parse_mode="Markdown"
    )
    await callback.answer()

@router.callback_query(F.data.startswith("admin_stk_"))
async def cb_admin_stock_prod_selected(callback: CallbackQuery, state: FSMContext):
    parts = callback.data.split("_")
    # format: admin_stk_add_PRODID or admin_stk_bulk_PRODID
    action_type = parts[2]
    prod_id = int(parts[3])
    
    await state.update_data(stock_prod_id=prod_id)
    
    product = await get_product(prod_id)
    prod_name = product['name_en'] if product else "Product"
    
    if action_type == "add":
        await state.set_state(StockStates.waiting_for_stock_data)
        await callback.message.answer(f"📥 *Add Stock to {prod_name}*:\nPlease send the item credentials/text:")
    else:
        await state.set_state(StockStates.waiting_for_bulk_stock)
        await callback.message.answer(f"📦 *Bulk Add Stock to {prod_name}*:\nPlease send a list of items (one item per line):")
        
    await callback.answer()

@router.message(StockStates.waiting_for_stock_data)
async def process_single_stock(message: Message, state: FSMContext):
    data = await state.get_data()
    prod_id = data.get("stock_prod_id")
    await state.clear()
    
    if not prod_id:
        await message.answer("❌ Session expired. Try again.")
        return
        
    await add_stock(prod_id, message.text)
    await message.answer("✅ Stock item added successfully!", reply_markup=keyboards.get_admin_back_keyboard())

@router.message(StockStates.waiting_for_bulk_stock)
async def process_bulk_stock(message: Message, state: FSMContext, bot: Bot, lang='en'):
    data = await state.get_data()
    prod_id = data.get("stock_prod_id")
    await state.clear()
    
    if not prod_id:
        await message.answer("❌ Session expired. Try again. / انتهت الجلسة، أعد المحاولة.")
        return
        
    text_content = ""
    if message.document:
        file_name = message.document.file_name or ""
        if not file_name.lower().endswith('.txt'):
            await message.answer("❌ Please upload a text file (.txt). / يرجى رفع ملف نصي بصيغة .txt")
            return
            
        from io import BytesIO
        file_buffer = BytesIO()
        await bot.download(message.document, destination=file_buffer)
        file_buffer.seek(0)
        text_content = file_buffer.read().decode('utf-8', errors='ignore')
    elif message.text:
        text_content = message.text
    else:
        await message.answer("❌ Please send stock items as text or upload a .txt file. / يرجى إرسال مخزون كنص أو رفع ملف .txt")
        return
        
    lines = [line.strip() for line in text_content.split("\n") if line.strip()]
    if not lines:
        await message.answer("❌ No valid items found in the input. / لم يتم العثور على عناصر صالحة.")
        return
        
    await bulk_add_stock(prod_id, lines)
    
    # Notify Admin
    success_msg = (
        f"✅ Bulk added {len(lines)} stock items successfully!\n"
        f"✅ تم إضافة {len(lines)} منتج (مخزون) بنجاح!"
    )
    await message.answer(success_msg, reply_markup=keyboards.get_admin_back_keyboard())
    
    product = await get_product(prod_id)
    prod_name = product['name_en'] if product else "Product"
    prod_name_ar = product['name_ar'] if product else "منتج"
            
    # Send News Channel announcement
    news_channel = await get_setting('news_channel', '')
    if news_channel and product:
        try:
            import html
            from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
            bot_info = await bot.get_me()
            bot_username = bot_info.username
            escaped_prod_name = html.escape(prod_name)
            announce_text = (
                f"⚡️ <b>PRODUCT RESTOCKED</b> ⚡️\n"
                f"──────────────────\n"
                f"🛍 <b>Product:</b> <code>{escaped_prod_name}</code>\n"
                f"📦 <b>Items Added:</b> <code>{len(lines)} units</code>\n"
                f"💵 <b>Price:</b> <code>${product['price']:.2f} USD</code>\n"
                f"──────────────────\n"
                f"👉 <i>Available now at:</i> @{bot_username}"
            )
            kb = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text="🛍️ Shop Now", url=f"https://t.me/{bot_username}")]
            ])
            await bot.send_message(chat_id=news_channel, text=announce_text, parse_mode="HTML", reply_markup=kb)
        except Exception as e:
            logger.error(f"Failed to send restock announcement to news channel: {e}")

# --- Config Settings ---
@router.callback_query(F.data.in_([
    "admin_channels", "admin_support_settings", 
    "admin_charge_settings", "admin_referral_settings",
    "admin_api_keys_settings"
]))
async def cb_admin_settings_menu(callback: CallbackQuery, menu: str = None):
    menu = menu or callback.data
    text = ""
    from aiogram.utils.keyboard import InlineKeyboardBuilder
    builder = InlineKeyboardBuilder()
    
    if menu == "admin_channels":
        force_join = await get_setting("force_join_channels", "None")
        news_ch = await get_setting("news_channel", "None")
        text = (
            f"📢 *Channel Settings*\n\n"
            f"🔗 *Force Join:* `{force_join}`\n"
            f"📣 *News Channel:* `{news_ch}`"
        )
        builder.button(text="✍️ Set Force Join Channels", callback_data="admin_set_force_join")
        builder.button(text="✍️ Set News Channel", callback_data="admin_set_news_ch")
        
    elif menu == "admin_support_settings":
        support = await get_setting("support_username", "None")
        text = (
            f"🎧 *Support Settings*\n\n"
            f"👤 *Support Handle:* `{support}`"
        )
        builder.button(text="✍️ Edit Support Handle", callback_data="admin_set_support")
        
    elif menu == "admin_charge_settings":
        stars = await get_setting("stars_enabled", "1")
        stars_rate = await get_setting("stars_rate", "0.02")
        usdt_addr = await get_setting("crypto_addr_usdt", "0x89846777ea91dee2b25f0fcbf54884a4f79923d8")
        ltc_addr = await get_setting("crypto_addr_ltc", "LbEuNY2o5ePVyd7dqE4dTyNToAPDtcYMXR")
        ton_addr = await get_setting("crypto_addr_ton", "UQC8zbAwkf9-f8SzyYYITLU8Et4g-Cf7ffyQJIhip9nupHGo")
        
        s_status = "✅ Enabled" if stars == "1" else "❌ Disabled"
        
        text = (
            f"💳 *Deposit Settings*\n\n"
            f"⭐️ *Telegram Stars:* {s_status}\n"
            f"💱 *Stars Exchange Rate:* 1 Star = `{stars_rate}` USD\n\n"
            f"🪙 *USDT BEP20 Address:* `{usdt_addr}`\n"
            f"🪙 *LTC Address:* `{ltc_addr}`\n"
            f"🪙 *TON Address:* `{ton_addr}`"
        )
        builder.button(text="Toggle Telegram Stars", callback_data="admin_toggle_stars")
        builder.button(text="Set Stars Exchange Rate", callback_data="admin_set_stars_rate")
        builder.button(text="✍️ Set USDT BEP20 Address", callback_data="admin_set_crypto_addr_usdt")
        builder.button(text="✍️ Set LTC Address", callback_data="admin_set_crypto_addr_ltc")
        builder.button(text="✍️ Set TON Address", callback_data="admin_set_crypto_addr_ton")
        
    elif menu == "admin_referral_settings":
        pct = await get_setting("referral_bonus_percent", "10")
        text = (
            f"👥 *Referral System Settings*\n\n"
            f"💰 *Bonus Percentage:* `{pct}%` of referral deposits"
        )
        builder.button(text="✍️ Edit Bonus Percentage", callback_data="admin_set_ref_pct")
        
    elif menu == "admin_api_keys_settings":
        bscscan_key = (await get_setting("bscscan_api_key", "")) or "None"
        blockcypher_key = (await get_setting("blockcypher_api_key", "")) or "None"
        toncenter_key = (await get_setting("toncenter_api_key", "")) or "None"
        
        text = (
            f"🔑 *API Keys Configuration*\n\n"
            f"🔸 *BscScan API Key:* `{bscscan_key}`\n"
            f"🔗 [Get BscScan Key](https://bscscan.com/myapikey)\n\n"
            f"🪙 *Blockcypher API Token:* `{blockcypher_key}`\n"
            f"🔗 [Get Blockcypher Token](https://accounts.blockcypher.com/)\n\n"
            f"💎 *Toncenter API Key:* `{toncenter_key}`\n"
            f"🔗 [Get Toncenter Key](https://t.me/toncenter)"
        )
        builder.button(text="✍️ Set BscScan API Key", callback_data="admin_set_bscscan_api_key")
        builder.button(text="✍️ Set Blockcypher API Token", callback_data="admin_set_blockcypher_api_key")
        builder.button(text="✍️ Set Toncenter API Key", callback_data="admin_set_toncenter_api_key")
        
    builder.button(text="🔙 Back to Admin Menu", callback_data="admin_menu")
    builder.adjust(1)
    
    await callback.message.edit_text(text, reply_markup=builder.as_markup(), parse_mode="Markdown")
    await callback.answer()

# Settings FSM triggers
@router.callback_query(F.data.startswith("admin_set_"))
async def cb_admin_set_setting(callback: CallbackQuery, state: FSMContext):
    setting_key = callback.data.replace("admin_set_", "")
    await state.update_data(setting_key=setting_key)
    await state.set_state(AdminStates.waiting_for_setting_value)
    
    prompts = {
        "force_join": "📢 Enter channels list (comma-separated, e.g. `@channel1,@my_channel` or leave blank to disable):",
        "news_ch": "📣 Enter news channel username or ID (e.g. `@my_news_channel` or `-10012345678`):",
        "support": "🎧 Enter support handler username (e.g. `@support_username`):",
        "stars_rate": "💱 Enter exchange rate (USD value per 1 Star, e.g. `0.02`):",
        "ref_pct": "👥 Enter referral bonus percentage (e.g. `10` for 10%):",
        "crypto_addr_usdt": "🪙 Enter new USDT BEP20 address:",
        "crypto_addr_ltc": "🪙 Enter new Litecoin (LTC) address:",
        "crypto_addr_ton": "🪙 Enter new TON address:",
        "bscscan_api_key": "🔸 Enter BscScan API Key (get from https://bscscan.com/myapikey):",
        "blockcypher_api_key": "🪙 Enter Blockcypher API Token (get from https://accounts.blockcypher.com/):",
        "toncenter_api_key": "💎 Enter Toncenter API Key (get from @toncenter bot: https://t.me/toncenter):"
    }
    
    prompt = prompts.get(setting_key, "Enter new value:")
    await callback.message.answer(prompt)
    await callback.answer()
 
@router.message(AdminStates.waiting_for_setting_value)
async def process_setting_value(message: Message, state: FSMContext):
    data = await state.get_data()
    setting_key = data.get("setting_key")
    await state.clear()
    
    val = message.text.strip()
    
    # Save setting key mappings
    db_keys = {
        "force_join": "force_join_channels",
        "news_ch": "news_channel",
        "support": "support_username",
        "stars_rate": "stars_rate",
        "ref_pct": "referral_bonus_percent",
        "crypto_addr_usdt": "crypto_addr_usdt",
        "crypto_addr_ltc": "crypto_addr_ltc",
        "crypto_addr_ton": "crypto_addr_ton",
        "bscscan_api_key": "bscscan_api_key",
        "blockcypher_api_key": "blockcypher_api_key",
        "toncenter_api_key": "toncenter_api_key"
    }
    
    db_key = db_keys.get(setting_key)
    if not db_key:
        await message.answer("❌ Invalid setting key.")
        return
        
    # Validate number keys
    if setting_key in ["stars_rate", "ref_pct"]:
        try:
            float(val)
        except ValueError:
            await message.answer("❌ Invalid number value. Change discarded.")
            return
            
    await set_setting(db_key, val)
    await message.answer(f"✅ Setting `{db_key}` updated to `{val}` successfully!", reply_markup=keyboards.get_admin_back_keyboard())
 
# Toggle Settings
@router.callback_query(F.data == "admin_toggle_stars")
async def cb_admin_toggle_payment(callback: CallbackQuery):
    method = "stars_enabled"
    current = await get_setting(method, "1")
    new_val = "0" if current == "1" else "1"
    await set_setting(method, new_val)
    
    await callback.answer(f"Toggled payment option!")
    # Reload settings menu without mutating callback.data
    await cb_admin_settings_menu(callback, menu="admin_charge_settings")

# --- Admin Broadcast ---
@router.callback_query(F.data == "admin_broadcast")
async def cb_admin_broadcast_trigger(callback: CallbackQuery, state: FSMContext):
    if not is_user_admin(callback.from_user.id):
        return
    await state.set_state(AdminStates.waiting_for_broadcast)
    await callback.message.answer("📣 Send the message you want to broadcast to *all users* (can contain formatting or markdown):")
    await callback.answer()

@router.message(AdminStates.waiting_for_broadcast)
async def process_admin_broadcast(message: Message, state: FSMContext, bot: Bot):
    user_id = message.from_user.id
    if not is_user_admin(user_id):
        await state.clear()
        return
        
    broadcast_msg = message.text
    await state.clear()
    
    users = await get_all_users()
    if not users:
        await message.answer("❌ No users found in the database.")
        return
        
    wait_msg = await message.answer(f"⏳ Broadcasting to {len(users)} users...")
    
    success = 0
    fail = 0
    for u in users:
        try:
            # We broadcast the exact text
            await bot.send_message(chat_id=u['user_id'], text=broadcast_msg, parse_mode="Markdown")
            success += 1
        except Exception as e:
            fail += 1
            logger.warning(f"Could not broadcast to {u['user_id']}: {e}")
            
    await wait_msg.edit_text(
        f"📣 *Broadcast Completed!*\n\n"
        f"✅ *Successful:* `{success}`\n"
        f"❌ *Failed:* `{fail}`",
        reply_markup=keyboards.get_admin_back_keyboard(),
        parse_mode="Markdown"
    )

# --- Admin Payment Approval Handlers ---
@router.callback_query(F.data.startswith("admin_pay_approve_"))
async def cb_admin_pay_approve(callback: CallbackQuery, bot: Bot):
    if not is_user_admin(callback.from_user.id):
        await callback.answer("Not authorized.")
        return
        
    transaction_id = callback.data.replace("admin_pay_approve_", "")
    
    from database import complete_payment
    result = await complete_payment(transaction_id)
    
    if not result:
        await callback.answer("❌ This transaction is not pending or has already been processed.", show_alert=True)
        return
        
    user_id = result['user_id']
    amount = result['amount']
    
    # Get user details for language and notifications
    db_user = await get_user(user_id)
    user_lang = db_user['language'] if db_user else 'en'
    new_balance = db_user['balance'] if db_user else 0.0
    
    # Notify user
    try:
        await bot.send_message(
            chat_id=user_id,
            text=get_text('payment_success', user_lang, amount=amount, new_balance=new_balance),
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.warning(f"Could not notify user {user_id} of approval: {e}")
        
    # Notify referrer if any
    ref_notif = result['referrer_notif']
    if ref_notif:
        ref_id = ref_notif['referrer_id']
        ref_bonus = ref_notif['bonus']
        try:
            await bot.send_message(
                chat_id=ref_id,
                text=f"🎉 *Referral Bonus!*\n💰 You earned `${ref_bonus:.2f} USD` from your referral's deposit!",
                parse_mode="Markdown"
            )
        except Exception as e:
            logger.warning(f"Could not notify referrer {ref_id}: {e}")
            
    # Edit admin log message to show approval
    admin_user = callback.from_user.first_name
    original_text = callback.message.text or callback.message.caption or ""
    # Escape markdown characters in original plain text to prevent parse errors
    safe_text = original_text.replace("\\", "\\\\").replace("_", "\\_").replace("*", "\\*").replace("`", "\\`").replace("[", "\\[")
    updated_text = (
        f"{safe_text}\n\n"
        f"✅ *Approved by admin:* {admin_user}"
    )
    
    await callback.message.edit_text(updated_text, reply_markup=None, parse_mode="Markdown")
    await callback.answer("Transaction approved and user credited!")

@router.callback_query(F.data.startswith("admin_pay_reject_"))
async def cb_admin_pay_reject(callback: CallbackQuery, bot: Bot):
    if not is_user_admin(callback.from_user.id):
        await callback.answer("Not authorized.")
        return
        
    transaction_id = callback.data.replace("admin_pay_reject_", "")
    
    from database import reject_payment
    payment = await reject_payment(transaction_id)
    
    if not payment:
        await callback.answer("❌ This transaction is not pending or has already been processed.", show_alert=True)
        return
        
    user_id = payment['user_id']
    amount = payment['amount']
    
    # Get user details for language and notifications
    db_user = await get_user(user_id)
    user_lang = db_user['language'] if db_user else 'en'
    
    # Notify user of rejection
    try:
        await bot.send_message(
            chat_id=user_id,
            text=get_text('payment_rejected', user_lang, amount=amount),
            parse_mode="Markdown"
        )
    except Exception as e:
        logger.warning(f"Could not notify user {user_id} of rejection: {e}")
        
    # Edit admin log message to show rejection
    admin_user = callback.from_user.first_name
    original_text = callback.message.text or callback.message.caption or ""
    # Escape markdown characters in original plain text to prevent parse errors
    safe_text = original_text.replace("\\", "\\\\").replace("_", "\\_").replace("*", "\\*").replace("`", "\\`").replace("[", "\\[")
    updated_text = (
        f"{safe_text}\n\n"
        f"❌ *Rejected by admin:* {admin_user}"
    )
    
    await callback.message.edit_text(updated_text, reply_markup=None, parse_mode="Markdown")
    await callback.answer("Transaction rejected!")

# --- User Discounts Management ---
@router.message(F.text == "👥 User Discounts")
async def msg_admin_discounts_menu(message: Message):
    if not is_user_admin(message.from_user.id):
        return
        
    from database import get_all_user_discounts
    discounts = await get_all_user_discounts()
    
    text = (
        "👥 *User Discounts Configuration*\n\n"
        "Here you can manage custom percentage discounts for specific users. "
        "A user with a discount will automatically get the corresponding price deduction at checkout."
    )
    
    await message.answer(
        text,
        reply_markup=keyboards.get_admin_discounts_keyboard(discounts),
        parse_mode="Markdown"
    )

@router.callback_query(F.data == "admin_discounts_menu")
async def cb_admin_discounts_menu(callback: CallbackQuery):
    if not is_user_admin(callback.from_user.id):
        return
        
    from database import get_all_user_discounts
    discounts = await get_all_user_discounts()
    
    text = (
        "👥 *User Discounts Configuration*\n\n"
        "Here you can manage custom percentage discounts for specific users. "
        "A user with a discount will automatically get the corresponding price deduction at checkout."
    )
    
    await callback.message.edit_text(
        text,
        reply_markup=keyboards.get_admin_discounts_keyboard(discounts),
        parse_mode="Markdown"
    )
    await callback.answer()

@router.callback_query(F.data.startswith("admin_discount_del_"))
async def cb_admin_discount_del(callback: CallbackQuery):
    if not is_user_admin(callback.from_user.id):
        return
        
    user_id = int(callback.data.replace("admin_discount_del_", ""))
    from database import delete_user_discount
    await delete_user_discount(user_id)
    
    await callback.answer("Discount deleted successfully!", show_alert=True)
    
    # Refresh view
    from database import get_all_user_discounts
    discounts = await get_all_user_discounts()
    await callback.message.edit_text(
        "👥 *User Discounts Configuration*\n\n"
        "Here you can manage custom percentage discounts for specific users. "
        "A user with a discount will automatically get the corresponding price deduction at checkout.",
        reply_markup=keyboards.get_admin_discounts_keyboard(discounts),
        parse_mode="Markdown"
    )

@router.callback_query(F.data == "admin_discount_add")
async def cb_admin_discount_add(callback: CallbackQuery, state: FSMContext):
    if not is_user_admin(callback.from_user.id):
        return
        
    await state.set_state(AdminStates.waiting_for_discount_user_id)
    await callback.message.answer("👥 Please enter the **User ID** of the user you want to grant a discount to:")
    await callback.answer()

@router.message(AdminStates.waiting_for_discount_user_id)
async def process_discount_user_id(message: Message, state: FSMContext):
    if not is_user_admin(message.from_user.id):
        await state.clear()
        return
        
    val = message.text.strip()
    try:
        user_id = int(val)
    except ValueError:
        await message.answer("❌ Invalid User ID. Please enter a valid numerical User ID:")
        return
        
    # Check if user exists in database
    from database import get_user
    db_user = await get_user(user_id)
    if not db_user:
        await message.answer("❌ User not found in the database. The user must start/use the bot at least once. Please check the ID and try again:")
        return
        
    await state.update_data(discount_target_user_id=user_id)
    await state.set_state(AdminStates.waiting_for_discount_percent)
    
    name = db_user['first_name']
    if db_user['username']:
        name += f" (@{db_user['username']})"
    await message.answer(f"👤 Found User: *{name}* (`{user_id}`)\n\nNow, enter the **Discount Percentage** (e.g. `15` for 15%):")

@router.message(AdminStates.waiting_for_discount_percent)
async def process_discount_percent(message: Message, state: FSMContext):
    if not is_user_admin(message.from_user.id):
        await state.clear()
        return
        
    val = message.text.strip()
    try:
        percent = float(val)
        if percent < 0 or percent > 100:
            raise ValueError()
    except ValueError:
        await message.answer("❌ Invalid percentage. Please enter a number between `0` and `100`:")
        return
        
    data = await state.get_data()
    user_id = data.get("discount_target_user_id")
    await state.clear()
    
    if not user_id:
        await message.answer("❌ Session expired. Please try again.")
        return
        
    from database import set_user_discount, get_user
    await set_user_discount(user_id, percent)
    
    db_user = await get_user(user_id)
    name = db_user['first_name'] if db_user else f"ID: {user_id}"
    await message.answer(
        f"✅ Successfully set discount of **{percent}%** for *{name}*!",
        reply_markup=keyboards.get_admin_back_keyboard()
    )

@router.callback_query(F.data.startswith("admin_discount_edit_"))
async def cb_admin_discount_edit(callback: CallbackQuery, state: FSMContext):
    if not is_user_admin(callback.from_user.id):
        return
        
    user_id = int(callback.data.replace("admin_discount_edit_", ""))
    await state.update_data(discount_target_user_id=user_id)
    await state.set_state(AdminStates.waiting_for_edit_discount_percent)
    
    from database import get_user
    db_user = await get_user(user_id)
    name = db_user['first_name'] if db_user else f"ID: {user_id}"
    await callback.message.answer(f"✏️ Enter the new discount percentage for *{name}* (e.g. `20` for 20%):")
    await callback.answer()

@router.message(AdminStates.waiting_for_edit_discount_percent)
async def process_edit_discount_percent(message: Message, state: FSMContext):
    if not is_user_admin(message.from_user.id):
        await state.clear()
        return
        
    val = message.text.strip()
    try:
        percent = float(val)
        if percent < 0 or percent > 100:
            raise ValueError()
    except ValueError:
        await message.answer("❌ Invalid percentage. Please enter a number between `0` and `100`:")
        return
        
    data = await state.get_data()
    user_id = data.get("discount_target_user_id")
    await state.clear()
    
    if not user_id:
        await message.answer("❌ Session expired. Please try again.")
        return
        
    from database import set_user_discount, get_user
    await set_user_discount(user_id, percent)
    
    db_user = await get_user(user_id)
    name = db_user['first_name'] if db_user else f"ID: {user_id}"
    await message.answer(
        f"✅ Successfully updated discount of **{percent}%** for *{name}*!",
        reply_markup=keyboards.get_admin_back_keyboard()
    )

# --- Edit Store Name ---
@router.message(F.text == "✏️ Edit Store Name")
async def msg_admin_edit_store_name(message: Message, state: FSMContext):
    if not is_user_admin(message.from_user.id):
        return
    
    current_name = await get_setting('store_name', 'Digital Store')
    await state.set_state(AdminStates.waiting_for_store_name)
    await message.answer(
        f"🏫 *Current Store Name:* `{current_name}`\n\n"
        f"✍️ *Please enter the new name for the store:*",
        parse_mode="Markdown"
    )

@router.message(AdminStates.waiting_for_store_name)
async def process_admin_store_name(message: Message, state: FSMContext):
    if not is_user_admin(message.from_user.id):
        await state.clear()
        return
        
    new_name = message.text.strip()
    if not new_name:
        await message.answer("❌ Store name cannot be empty. Please enter a valid name:")
        return
        
    await set_setting('store_name', new_name)
    await state.clear()
    
    await message.answer(
        f"✅ *Store name successfully updated to:* `{new_name}`",
        reply_markup=keyboards.get_admin_back_keyboard(),
        parse_mode="Markdown"
    )
