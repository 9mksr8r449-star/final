# Localization configurations for English, Arabic, and Russian

LOCALIZATION = {
    'welcome': {
        'en': "👋 Welcome *{name}* to *{store_name}*!\n\n💵 *Balance:* `${balance:.2f} USD`\n🔗 *Referred by:* `{referred_by}`\n👥 *Your Referrals:* `{ref_count}` users\n\nChoose an option from the menu below 👇",
        'ar': "👋 أهلاً بك يا *{name}* في *{store_name}*!\n\n💵 *الرصيد:* `${balance:.2f} USD`\n🔗 *تمت إحالتك بواسطة:* `{referred_by}`\n👥 *إحالاتك:* `{ref_count}` مستخدم\n\nاختر أحد الخيارات من القائمة أدناه 👇",
        'ru': "👋 Добро пожаловать, *{name}*, в *{store_name}*!\n\n💵 *Баланс:* `${balance:.2f} USD`\n🔗 *Вас пригласил:* `{referred_by}`\n👥 *Ваши рефералы:* `{ref_count}` польз.\n\nВыберите опцию в меню ниже 👇"
    },
    'btn_shop': {
        'en': "🛍️ Shop",
        'ar': "🛍️ المتجر",
        'ru': "🛍️ Магазин"
    },
    'btn_my_orders': {
        'en': "📦 My Orders",
        'ar': "📦 طلباتي",
        'ru': "📦 Мои заказы"
    },
    'btn_support': {
        'en': "🎧 Support",
        'ar': "🎧 الدعم",
        'ru': "🎧 Поддержка"
    },
    'btn_charge_balance': {
        'en': "💳 Charge Balance",
        'ar': "💳 شحن الرصيد",
        'ru': "💳 Пополнить баланс"
    },
    'btn_referral': {
        'en': "🔗 Referral Link",
        'ar': "🔗 رابط الإحالة",
        'ru': "🔗 Реферальная ссылка"
    },
    'btn_language': {
        'en': "🌐 Language / اللغة",
        'ar': "🌐 اللغة / Language",
        'ru': "🌐 Язык / Language"
    },
    'btn_admin_panel': {
        'en': "⚙️ Admin Panel",
        'ar': "⚙️ لوحة التحكم",
        'ru': "⚙️ Админ-панель"
    },
    'select_lang': {
        'en': "🌍 Please select your language / الرجاء اختيار اللغة / Пожалуйста, выберите язык:",
        'ar': "🌍 Please select your language / الرجاء اختيار اللغة / Пожалуйста, выберите язык:",
        'ru': "🌍 Please select your language / الرجاء اختيار اللغة / Пожалуйста, выберите язык:"
    },
    'lang_updated': {
        'en': "✅ Language updated to English!",
        'ar': "✅ تم تغيير اللغة إلى العربية!",
        'ru': "✅ Язык изменен на Русский!"
    },
    'support_info': {
        'en': "💬 To contact support, please contact the admin directly: @{username}",
        'ar': "💬 للتواصل مع الدعم، يرجى التواصل مع المسؤول مباشرة: @{username}",
        'ru': "💬 Для связи с поддержкой обратитесь к администратору напрямую: @{username}"
    },
    'btn_contact_support': {
        'en': "🎧 Contact Support",
        'ar': "🎧 تواصل مع الدعم",
        'ru': "🎧 Связаться с поддержкой"
    },
    'support_no_handle': {
        'en': "❌ Support is currently unavailable.",
        'ar': "❌ الدعم غير متوفر حالياً.",
        'ru': "❌ Поддержка временно недоступна."
    },
    'support_ticket_sent': {
        'en': "✅ Your message has been sent to support. We will get back to you shortly.",
        'ar': "✅ تم إرسال رسالتك إلى الدعم. سنرد عليك في أقرب وقت ممكن.",
        'ru': "✅ Ваше сообщение отправлено в поддержку. Мы ответим вам в ближайшее время."
    },
    'support_new_ticket': {
        'en': "📬 New Support Ticket from {name} (`{user_id}`):\n\n💬 `{message}`",
        'ar': "📬 تذكرة دعم جديدة من {name} (`{user_id}`):\n\n💬 `{message}`",
        'ru': "📬 Новое обращение от {name} (`{user_id}`):\n\n💬 `{message}`"
    },
    'support_reply_delivered': {
        'en': "🎧 *Support reply:* {reply}",
        'ar': "🎧 *رد الدعم:* {reply}",
        'ru': "🎧 *Ответ поддержки:* {reply}"
    },
    'referral_msg': {
        'en': "🔗 *Referral System*\n\nShare your referral link with friends. When they top up their balance, you receive *{bonus}%* of their charge amount!\n\n👥 *Your Referrals:* `{count}`\n💰 *Total Earned:* `${earned:.2f} USD`\n\n📋 *Your Link:* `{link}`",
        'ar': "🔗 *نظام الإحالات*\n\nشارك رابط الإحالة الخاص بك مع أصدقائك. عندما يقومون بشحن رصيدهم، ستحصل على *{bonus}%* من قيمة شحنهم!\n\n👥 *عدد إحالاتك:* `{count}`\n💰 *إجمالي الأرباح:* `${earned:.2f} USD`\n\n📋 *رابطك:* `{link}`",
        'ru': "🔗 *Реферальная система*\n\nПоделитесь своей реферальной ссылкой. Когда ваши рефералы пополняют баланс, вы получаете *{bonus}%* от суммы их пополнения!\n\n👥 *Ваши рефералы:* `{count}`\n💰 *Всего заработано:* `${earned:.2f} USD`\n\n📋 *Ваша ссылка:* `{link}`"
    },
    'my_orders_title': {
        'en': "📦 *Your Purchase History:*",
        'ar': "📦 *سجل مشترياتك:*",
        'ru': "📦 *История ваших покупок:*"
    },
    'my_orders_empty': {
        'en': "📭 You haven't made any purchases yet.",
        'ar': "📭 لم تقم بأي عمليات شراء بعد.",
        'ru': "📭 Вы еще не совершали покупок."
    },
    'order_item': {
        'en': "🆔 *Order #{id}*\n🛍️ *Product:* {name}\n💵 *Paid:* `${price:.2f} USD`\n📅 *Date:* {date}\n📦 *Data delivered:* \n`{data}`\n\n" + ("=" * 20),
        'ar': "🆔 *طلب #{id}*\n🛍️ *المنتج:* {name}\n💵 *المدفوع:* `${price:.2f} USD`\n📅 *التاريخ:* {date}\n📦 *البيانات المرسلة:* \n`{data}`\n\n" + ("=" * 20),
        'ru': "🆔 *Заказ #{id}*\n🛍️ *Товар:* {name}\n💵 *Оплачено:* `${price:.2f} USD`\n📅 *Дата:* {date}\n📦 *Доставленные данные:* \n`{data}`\n\n" + ("=" * 20)
    },
    'shop_title': {
        'en': "🛍️ *Store Products*\nSelect a product to view details and purchase:",
        'ar': "🛍️ *منتجات المتجر*\nاختر منتجاً لعرض التفاصيل والشراء:",
        'ru': "🛍️ *Товары магазина*\nВыберите товар для просмотра деталей и покупки:"
    },
    'shop_empty': {
        'en': "📭 No products available right now.",
        'ar': "📭 لا توجد منتجات متوفرة حالياً.",
        'ru': "📭 В данный момент товаров нет."
    },
    'product_details': {
        'en': "🛍️ *Product:* {name}\n\n📝 *Description:* {desc}\n\n💵 *Price:* {price}\n📦 *Stock:* `{stock}` available",
        'ar': "🛍️ *المنتج:* {name}\n\n📝 *الوصف:* {desc}\n\n💵 *السعر:* {price}\n📦 *المخزون:* `{stock}` متوفر",
        'ru': "🛍️ *Товар:* {name}\n\n📝 *Описание:* {desc}\n\n💵 *Цена:* {price}\n📦 *В наличии:* `{stock}` шт."
    },
    'btn_buy': {
        'en': "🛒 Buy Now",
        'ar': "🛒 شراء الآن",
        'ru': "🛒 Купить сейчас"
    },
    'btn_back': {
        'en': "🔙 Back",
        'ar': "🔙 عودة",
        'ru': "🔙 Назад"
    },
    'out_of_stock': {
        'en': "❌ Sorry, this product is out of stock.",
        'ar': "❌ عذراً، هذا المنتج غير متوفر في المخزون حالياً.",
        'ru': "❌ К сожалению, товара нет в наличии."
    },
    'insufficient_balance': {
        'en': "❌ Insufficient balance. Please charge your balance first. Your balance is `${balance:.2f} USD` but the product costs `${price:.2f} USD`.",
        'ar': "❌ الرصيد غير كافٍ. يرجى شحن رصيدك أولاً. رصيدك الحالي هو `${balance:.2f} USD` وسعر المنتج هو `${price:.2f} USD`.",
        'ru': "❌ Недостаточно средств. Пожалуйста, пополните баланс. Ваш баланс `${balance:.2f} USD`, стоимость товара `${price:.2f} USD`."
    },
    'purchase_success': {
        'en': "🎉 *Purchase Successful!*\n\n🛍️ *Product:* {name}\n💵 *Paid:* `${price:.2f} USD`\n📦 *Your Item/Credentials:* \n\n`{data}`\n\nThank you for shopping with us! ❤️",
        'ar': "🎉 *تمت عملية الشراء بنجاح!*\n\n🛍️ *المنتج:* {name}\n💵 *المدفوع:* `${price:.2f} USD`\n📦 *بيانات المنتج:* \n\n`{data}`\n\nشكراً لشرائك من متجرنا! ❤️",
        'ru': "🎉 *Покупка успешно совершена!*\n\n🛍️ *Товар:* {name}\n💵 *Оплачено:* `${price:.2f} USD`\n📦 *Ваши данные:* \n\n`{data}`\n\nСпасибо за покупку! ❤️"
    },
    'charge_title': {
        'en': "💳 *Charge Balance*\n\nChoose your preferred payment method below. Your current balance is `${balance:.2f} USD`.",
        'ar': "💳 *شحن الرصيد*\n\nاختر طريقة الدفع المفضلة لديك أدناه. رصيدك الحالي هو `${balance:.2f} USD`.",
        'ru': "💳 *Пополнение баланса*\n\nВыберите предпочтительный способ оплаты. Ваш текущий баланс: `${balance:.2f} USD`."
    },
    'btn_binance_pay': {
        'en': "🔸 Binance Pay (USDT)",
        'ar': "🔸 بايننس باي (USDT)",
        'ru': "🔸 Binance Pay (USDT)"
    },
    'btn_stars': {
        'en': "⭐️ Telegram Stars",
        'ar': "⭐️ نجوم تلغرام",
        'ru': "⭐️ Telegram Stars"
    },
    'btn_cryptotransfer': {
        'en': "🪙 Crypto Transfer (Manual)",
        'ar': "🪙 تحويل العملات الرقمية (يدوي)",
        'ru': "🪙 Крипто-перевод (Вручную)"
    },
    'crypto_select_coin': {
        'en': "🌍 Select cryptocurrency / اختر العملة الرقمية / Выберите криптовалюту:",
        'ar': "🌍 Select cryptocurrency / اختر العملة الرقمية / Выберите криптовалюту:",
        'ru': "🌍 Select cryptocurrency / اختر العملة الرقمية / Выберите криптовалюту:"
    },
    'crypto_instructions': {
        'en': "🪙 *Crypto Transfer*\n\nSend your payment to the address below:\n\n*Coin:* `{coin}`\n*Address:* `{address}`\n\nAfter sending, reply with the amount you sent in USD (Minimum $1.00):",
        'ar': "🪙 *تحويل العملات الرقمية*\n\nقم بإرسال المبلغ إلى العنوان التالي:\n\n*العملة:* `{coin}`\n*العنوان:* `{address}`\n\nبعد الإرسال، أرسل المبلغ الذي قمت بتحويله بالدولار (الحد الأدنى $1.00):",
        'ru': "🪙 *Крипто-перевод*\n\nОтправьте оплату на адрес ниже:\n\n*Монета:* `{coin}`\n*Адрес:* `{address}`\n\nПосле отправки введите отправленную сумму в USD (Минимум $1.00):"
    },
    'crypto_enter_txid': {
        'en': "✍️ Now enter the Transaction ID (TxID / Hash) to verify payment:",
        'ar': "✍️ الآن أرسل معرف المعاملة (TxID / Hash) للتحقق من الدفع:",
        'ru': "✍️ Теперь введите ID транзакции (TxID / Hash) для проверки:"
    },
    'crypto_deposit_submitted': {
        'en': "✅ *Deposit Submitted!*\n\nYour transaction has been submitted to admins for review. Your balance will be updated once confirmed.",
        'ar': "✅ *تم إرسال الطلب!*\n\nتم تقديم معاملتك للمشرفين للمراجعة. سيتم تحديث رصيدك فور تأكيد المعاملة.",
        'ru': "✅ *Запрос отправлен!*\n\nВаша транзакция отправлена администраторам на проверку. Баланс обновится после подтверждения."
    },
    'crypto_deposit_submitted_auto': {
        'en': "⏳ *Transaction Submitted!*\n\nWe are verifying your deposit automatically on the blockchain. This usually takes a few minutes. Your balance will update automatically.",
        'ar': "⏳ *تم إرسال المعاملة!*\n\nجاري التحقق من عملية الإيداع تلقائياً على الشبكة. يستغرق ذلك عادةً بضع دقائق، وسيتم تحديث رصيدك تلقائياً.",
        'ru': "⏳ *Транзакция отправлена!*\n\nМы проверяем ваш перевод автоматически на блокчейне. Обычно это занимает несколько минут. Ваш баланс обновится автоматически."
    },
    'crypto_already_processed': {
        'en': "❌ This transaction has already been processed or rejected.",
        'ar': "❌ تم معالجة هذه المعاملة أو رفضها بالفعل.",
        'ru': "❌ Эта транзакция уже была обработана или отклонена."
    },
    'enter_amount_usd': {
        'en': "💵 Enter the amount you want to deposit in USD (Minimum $1.00):",
        'ar': "💵 أدخل المبلغ الذي تريد شحنه بالدولار (الحد الأدنى $1.00):",
        'ru': "💵 Введите сумму пополнения в USD (Минимум $1.00):"
    },
    'invalid_amount': {
        'en': "❌ Invalid amount. Please enter a positive number greater than or equal to 1.",
        'ar': "❌ مبلغ غير صالح. يرجى إدخال رقم موجب أكبر من أو يساوي 1.",
        'ru': "❌ Неверная сумма. Введите положительное число не меньше 1."
    },
    'binance_instructions': {
        'en': "🔸 *Binance Pay Deposit*\n\n💰 *Amount:* `${amount:.2f} USD`\n\nClick the button below to pay via Binance. After paying, click the status button below to check and confirm your payment.",
        'ar': "🔸 *الدفع عبر Binance Pay*\n\n💰 *المبلغ:* `${amount:.2f} USD`\n\nاضغط على الزر أدناه لإتمام الدفع عبر بايننس. بعد الدفع، اضغط على زر التحقق أدناه لتأكيد شحنتك.",
        'ru': "🔸 *Пополнение через Binance Pay*\n\n💰 *Сумма:* `${amount:.2f} USD`\n\nНажмите кнопку ниже для оплаты. После оплаты нажмите кнопку проверки, чтобы подтвердить платеж."
    },
    'cryptobot_instructions': {
        'en': "🪙 *Crypto Bot Deposit*\n\n💰 *Amount:* `${amount:.2f} USD`\n\nClick the button below to pay via Crypto Bot (USDT). After paying, click the status button below to check and confirm your payment.",
        'ar': "🪙 *شحن عبر كريبتو بوت*\n\n💰 *المبلغ:* `${amount:.2f} USD`\n\nاضغط على الزر أدناه للدفع عبر كريبتو بوت (USDT). بعد إتمام الدفع، اضغط على زر التحقق أدناه لتأكيد شحنتك.",
        'ru': "🪙 *Пополнение через Crypto Bot*\n\n💰 *Сумма:* `${amount:.2f} USD`\n\nНажмите кнопку ниже для оплаты через Crypto Bot (USDT). После оплаты нажмите кнопку проверки, чтобы подтвердить платеж."
    },
    'btn_pay_now': {
        'en': "🔗 Pay Now",
        'ar': "🔗 ادفع الآن",
        'ru': "🔗 Оплатить сейчас"
    },
    'btn_check_payment': {
        'en': "🔄 Check Payment Status",
        'ar': "🔄 تحقق من حالة الدفع",
        'ru': "🔄 Проверить статус платежа"
    },
    'payment_pending_check': {
        'en': "⏳ Checking payment status... please wait.",
        'ar': "⏳ جاري التحقق من حالة الدفع... يرجى الانتظار.",
        'ru': "⏳ Проверка статуса платежа... пожалуйста, подождите."
    },
    'payment_not_found_or_pending': {
        'en': "❌ We couldn't find a completed payment for this transaction yet. Please make sure you paid first.",
        'ar': "❌ لم نجد دفعة مكتملة لهذه المعاملة بعد. يرجى التأكد من الدفع أولاً.",
        'ru': "❌ Мы еще не обнаружили оплату для этой транзакции. Убедитесь, что оплатили её."
    },
    'payment_success': {
        'en': "✅ *Deposit Successful!*\n\n💰 `${amount:.2f} USD` has been added to your balance. Your new balance is `${new_balance:.2f} USD`.",
        'ar': "✅ *تم الشحن بنجاح!*\n\n💰 تم إضافة `${amount:.2f} USD` لرصيدك. رصيدك الجديد هو `${new_balance:.2f} USD`.",
        'ru': "✅ *Баланс успешно пополнен!*\n\n💰 `${amount:.2f} USD` зачислено на ваш счет. Ваш новый баланс: `${new_balance:.2f} USD`."
    },
    'stars_invoice_title': {
        'en': "Deposit ${amount:.2f} USD",
        'ar': "شحن ${amount:.2f} USD",
        'ru': "Пополнение на ${amount:.2f} USD"
    },
    'stars_invoice_desc': {
        'en': "Top up your shop balance with ${amount:.2f} USD via Telegram Stars.",
        'ar': "شحن رصيد المتجر بقيمة ${amount:.2f} USD عبر نجوم التلغرام.",
        'ru': "Пополнение баланса магазина на ${amount:.2f} USD через Telegram Stars."
    },
    'force_join_msg': {
        'en': "📢 You must join our channel(s) to use this bot:\n\n{channels}\n\nAfter joining, press /start again to unlock the bot.",
        'ar': "📢 يجب عليك الانضمام إلى قنواتنا لاستخدام هذا البوت:\n\n{channels}\n\nبعد الانضمام، أرسل /start مجدداً لفتح البوت.",
        'ru': "📢 Вы должны подписаться на наши каналы, чтобы использовать этого бота:\n\n{channels}\n\nПосле подписки отправьте /start снова."
    },
    'admin_panel': {
        'en': "⚙️ *Admin Panel*\nChoose an action:",
        'ar': "⚙️ *لوحة التحكم للمشرف*\nاختر إجراءً للقيام به:",
        'ru': "⚙️ *Админ-панель*\nВыберите действие:"
    },
    'payment_rejected': {
        'en': "❌ *Deposit Rejected!*\n\nYour transaction of `${amount:.2f} USD` has been rejected by the admin. Please make sure the TxID and amount are correct.",
        'ar': "❌ *تم رفض الشحن!*\n\nتم رفض معاملتك بقيمة `${amount:.2f} USD` من قبل المشرف. يرجى التأكد من صحة معرف المعاملة (TxID) والمبلغ.",
        'ru': "❌ *Пополнение отклонено!*\n\nВаш платеж на сумму `${amount:.2f} USD` был отклонен администратором. Пожалуйста, убедитесь в правильности ID транзакции (TxID) и суммы."
    }
}

def get_text(key, lang='en', **kwargs):
    if key not in LOCALIZATION:
        return f"[{key}]"
    text = LOCALIZATION[key].get(lang, LOCALIZATION[key].get('en', f"[{key}]"))
    if kwargs:
        try:
            return text.format(**kwargs)
        except Exception:
            return text
    return text
