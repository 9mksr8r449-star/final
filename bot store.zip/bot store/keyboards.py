from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.utils.keyboard import ReplyKeyboardBuilder, InlineKeyboardBuilder
from localization import get_text
import config

def get_main_menu(lang='en', is_admin=False) -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    
    # We want a 2x3 or 2x4 grid for users
    builder.button(text=get_text('btn_shop', lang))
    builder.button(text=get_text('btn_my_orders', lang))
    builder.button(text=get_text('btn_charge_balance', lang))
    builder.button(text=get_text('btn_referral', lang))
    builder.button(text=get_text('btn_support', lang))
    builder.button(text=get_text('btn_language', lang))
    
    builder.adjust(2, 2, 2)
    
    if is_admin:
        # Add admin panel on its own line
        builder.row(KeyboardButton(text=get_text('btn_admin_panel', lang)))
        
    return builder.as_markup(resize_keyboard=True)

def get_language_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🇺🇸 English", callback_data="set_lang_en")
    builder.button(text="🇸🇦 العربية", callback_data="set_lang_ar")
    builder.button(text="🇷🇺 Русский", callback_data="set_lang_ru")
    builder.adjust(1)
    return builder.as_markup()

def get_products_keyboard(products, lang='en') -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for product in products:
        # Show product name + price
        name = product[f'name_{lang}']
        price = product['price']
        builder.button(
            text=f"{name} - ${price:.2f}",
            callback_data=f"prod_view_{product['id']}"
        )
    builder.adjust(1)
    return builder.as_markup()

def get_product_view_keyboard(product_id, has_stock, lang='en') -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if has_stock:
        builder.button(text=get_text('btn_buy', lang), callback_data=f"prod_buy_{product_id}")
    builder.button(text=get_text('btn_back', lang), callback_data="shop_list")
    builder.adjust(1)
    return builder.as_markup()

def get_charge_methods_keyboard(lang='en', stars_enabled=True) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    if stars_enabled:
        builder.button(text=get_text('btn_stars', lang), callback_data="charge_stars")
    builder.button(text=get_text('btn_cryptotransfer', lang), callback_data="charge_cryptotransfer")
    builder.button(text=get_text('btn_back', lang), callback_data="cancel_charge")
    builder.adjust(1)
    return builder.as_markup()

def get_crypto_coins_keyboard(lang='en') -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="USDT BEP20", callback_data="crypto_coin_USDT")
    builder.button(text="Litecoin (LTC)", callback_data="crypto_coin_LTC")
    builder.button(text="TON", callback_data="crypto_coin_TON")
    builder.button(text=get_text('btn_back', lang), callback_data="charge_menu")
    builder.adjust(1)
    return builder.as_markup()

def get_admin_payment_approval_keyboard(transaction_id) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✅ Approve", callback_data=f"admin_pay_approve_{transaction_id}")
    builder.button(text="❌ Reject", callback_data=f"admin_pay_reject_{transaction_id}")
    builder.adjust(2)
    return builder.as_markup()

# Admin Keyboard
def get_admin_reply_keyboard(lang='en') -> ReplyKeyboardMarkup:
    builder = ReplyKeyboardBuilder()
    builder.button(text="📦 Manage Products")
    builder.button(text="📥 Add Stock")
    builder.button(text="📦 Bulk Add Stock")
    builder.button(text="⏳ Pending Deposits")
    builder.button(text="📢 Channels Settings")
    builder.button(text="🎧 Support Settings")
    builder.button(text="💳 Charge Section")
    builder.button(text="👥 Referral System")
    builder.button(text="🔑 API Keys Settings")
    builder.button(text="👥 User Discounts")
    builder.button(text="📣 Broadcast")
    builder.button(text="✏️ Edit Store Name")
    builder.button(text="🔙 Back to Main Menu")
    builder.adjust(2, 2, 2, 2, 2, 2, 2)
    return builder.as_markup(resize_keyboard=True)

def get_admin_menu_keyboard(lang='en') -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📦 Manage Products", callback_data="admin_manage_products")
    builder.button(text="📢 Channels Settings", callback_data="admin_channels")
    builder.button(text="📥 Add Stock", callback_data="admin_add_stock")
    builder.button(text="📦 Bulk Add Stock", callback_data="admin_bulk_stock")
    builder.button(text="🎧 Support Settings", callback_data="admin_support_settings")
    builder.button(text="💳 Charge Section", callback_data="admin_charge_settings")
    builder.button(text="👥 Referral System", callback_data="admin_referral_settings")
    builder.button(text="📣 Broadcast", callback_data="admin_broadcast")
    builder.adjust(2, 2, 2, 2)
    return builder.as_markup()

def get_admin_products_keyboard(products) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    for product in products:
        builder.button(text=f"✏️ {product['name_en']} (${product['price']:.2f})", callback_data=f"admin_prod_edit_{product['id']}")
    builder.button(text="➕ Add Product", callback_data="admin_prod_add")
    builder.button(text="🔙 Back to Admin Menu", callback_data="admin_menu")
    builder.adjust(1)
    return builder.as_markup()

def get_admin_product_edit_keyboard(product_id) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="📝 Edit Details", callback_data=f"admin_edit_fields_{product_id}")
    builder.button(text="🗑️ Delete Product", callback_data=f"admin_prod_del_{product_id}")
    builder.button(text="🔙 Back", callback_data="admin_manage_products")
    builder.adjust(1)
    return builder.as_markup()

def get_admin_support_ticket_keyboard(user_id) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="✍️ Reply to User", callback_data=f"ticket_reply_{user_id}")
    return builder.as_markup()

def get_admin_back_keyboard() -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="🔙 Back to Admin Panel", callback_data="admin_menu")
    return builder.as_markup()

def get_admin_discounts_keyboard(discounts) -> InlineKeyboardMarkup:
    builder = InlineKeyboardBuilder()
    builder.button(text="➕ Add Discount / إضافة خصم", callback_data="admin_discount_add")
    for d in discounts:
        user_id = d['user_id']
        percent = d['discount_percent']
        name = d['first_name'] or f"ID: {user_id}"
        if d['username']:
            name += f" (@{d['username']})"
        builder.button(text=f"✏️ {name} - {percent}%", callback_data=f"admin_discount_edit_{user_id}")
        builder.button(text="❌ Delete / حذف", callback_data=f"admin_discount_del_{user_id}")
    builder.button(text="🔙 Back to Admin Menu", callback_data="admin_menu")
    
    # Adjust layout: Add button [1], each discount [2] (edit, delete), Back button [1]
    adjust_pattern = [1]
    for _ in range(len(discounts)):
        adjust_pattern.append(2)
    adjust_pattern.append(1)
    builder.adjust(*adjust_pattern)
    return builder.as_markup()
